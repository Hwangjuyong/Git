Imports Frame8
Imports Base8
Imports Base8.Shared

Public Class MMD700
    Private Sub LEA311_Load(sender As Object, e As EventArgs) Handles Me.Load
        pi_no.CodeNo = "MMD600"
        pi_no.CodeDateField = pi_dt

    End Sub
    Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)

        Select Case mty

            Case MenuType.Save
                If Me.Save Then
                    PutMessage("SYS_SAVE", "Save Success.")
                    Me.Open()
                End If
            Case MenuType.New
                pi_no.Text = ""
                OpenTrigger("mmd700_g10")

                'f_po_no.Text = ""

                'Me.OpenTrigger("MMD700_g10")
                ''Case MenuType.Save
                ''    If Me.Save Then
                ''        Me.Open()
                ''    End If
            Case MenuType.Delete
                Delete("MMD700_f10")
                Me.Open()
            Case Else

                MyBase.MenuButton_Click(mty)

        End Select

    End Sub
End Class
