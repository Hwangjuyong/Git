<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MMD700
    Inherits Base8.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.EPanel2 = New Frame8.ePanel()
        Me.f_pi_no = New Frame8.eText()
        Me.f_po_no = New Frame8.eText()
        Me.f_buyer = New Frame8.eText()
        Me.f_manu = New Frame8.eText()
        Me.to_dt = New Frame8.eDate()
        Me.fr_dt = New Frame8.eDate()
        Me.wh_cd = New Frame8.eCombo()
        Me.bs_cd = New Frame8.eCombo()
        Me.co_cd = New Frame8.eCombo()
        Me.EPanel3 = New Frame8.ePanel()
        Me.g10 = New Frame8.eGrid()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.EPanel4 = New Frame8.ePanel()
        Me.btn_pi = New Frame8.eButton()
        Me.pay_term = New Frame8.eCombo()
        Me.income_term = New Frame8.eCombo()
        Me.pod = New Frame8.eCombo()
        Me.pol = New Frame8.eCombo()
        Me.dest_cd = New Frame8.eCombo()
        Me.status = New Frame8.eCombo()
        Me.ship_dt = New Frame8.eDate()
        Me.pi_dt = New Frame8.eDate()
        Me.consignee = New Frame8.eText()
        Me.rmks = New Frame8.eText()
        Me.packing = New Frame8.eText()
        Me.shipper = New Frame8.eText()
        Me.po_no = New Frame8.eText()
        Me.manu_cd = New Frame8.eText()
        Me.pi_no = New Frame8.eText()
        Me.EPanel1 = New Frame8.ePanel()
        Me.g20 = New Frame8.eGrid()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel2.SuspendLayout()
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel3.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel4.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.SplitContainer3)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer1)
        Me.SplitContainer2.Size = New System.Drawing.Size(1617, 765)
        Me.SplitContainer2.SplitterDistance = 407
        Me.SplitContainer2.TabIndex = 4
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.EPanel2)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.EPanel3)
        Me.SplitContainer3.Size = New System.Drawing.Size(407, 765)
        Me.SplitContainer3.SplitterDistance = 123
        Me.SplitContainer3.TabIndex = 2
        '
        'EPanel2
        '
        Me.EPanel2.Controls.Add(Me.f_pi_no)
        Me.EPanel2.Controls.Add(Me.f_po_no)
        Me.EPanel2.Controls.Add(Me.f_buyer)
        Me.EPanel2.Controls.Add(Me.f_manu)
        Me.EPanel2.Controls.Add(Me.to_dt)
        Me.EPanel2.Controls.Add(Me.fr_dt)
        Me.EPanel2.Controls.Add(Me.wh_cd)
        Me.EPanel2.Controls.Add(Me.bs_cd)
        Me.EPanel2.Controls.Add(Me.co_cd)
        Me.EPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel2.Location = New System.Drawing.Point(0, 0)
        Me.EPanel2.Name = "EPanel2"
        Me.EPanel2.Size = New System.Drawing.Size(407, 123)
        Me.EPanel2.TabIndex = 4
        Me.EPanel2.Text = "     Serch"
        '
        'f_pi_no
        '
        Me.f_pi_no.Location = New System.Drawing.Point(206, 72)
        Me.f_pi_no.Name = "f_pi_no"
        Me.f_pi_no.Size = New System.Drawing.Size(195, 24)
        Me.f_pi_no.TabIndex = 4
        Me.f_pi_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_pi_no.Title = "f_pi_no"
        Me.f_pi_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_pi_no.TitleWidth = 80
        '
        'f_po_no
        '
        Me.f_po_no.Location = New System.Drawing.Point(206, 96)
        Me.f_po_no.Name = "f_po_no"
        Me.f_po_no.Size = New System.Drawing.Size(195, 24)
        Me.f_po_no.TabIndex = 4
        Me.f_po_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_po_no.Title = "f_po_no"
        Me.f_po_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_po_no.TitleWidth = 80
        '
        'f_buyer
        '
        Me.f_buyer.Location = New System.Drawing.Point(5, 225)
        Me.f_buyer.Name = "f_buyer"
        Me.f_buyer.Size = New System.Drawing.Size(195, 24)
        Me.f_buyer.TabIndex = 4
        Me.f_buyer.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_buyer.Title = "f_buyer"
        Me.f_buyer.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_buyer.TitleWidth = 80
        '
        'f_manu
        '
        Me.f_manu.Location = New System.Drawing.Point(5, 202)
        Me.f_manu.Name = "f_manu"
        Me.f_manu.Size = New System.Drawing.Size(195, 24)
        Me.f_manu.TabIndex = 4
        Me.f_manu.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_manu.Title = "f_manu"
        Me.f_manu.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_manu.TitleWidth = 80
        '
        'to_dt
        '
        Me.to_dt.Location = New System.Drawing.Point(206, 48)
        Me.to_dt.Name = "to_dt"
        Me.to_dt.Size = New System.Drawing.Size(195, 24)
        Me.to_dt.TabIndex = 3
        Me.to_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.to_dt.Title = "to_dt"
        Me.to_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.to_dt.TitleWidth = 80
        '
        'fr_dt
        '
        Me.fr_dt.Location = New System.Drawing.Point(206, 25)
        Me.fr_dt.Name = "fr_dt"
        Me.fr_dt.Size = New System.Drawing.Size(195, 24)
        Me.fr_dt.TabIndex = 3
        Me.fr_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.fr_dt.Title = "fr_dt"
        Me.fr_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.fr_dt.TitleWidth = 80
        '
        'wh_cd
        '
        Me.wh_cd.Location = New System.Drawing.Point(5, 71)
        Me.wh_cd.Name = "wh_cd"
        Me.wh_cd.Size = New System.Drawing.Size(195, 24)
        Me.wh_cd.TabIndex = 2
        Me.wh_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.wh_cd.Title = "wh_cd"
        Me.wh_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.wh_cd.TitleWidth = 80
        '
        'bs_cd
        '
        Me.bs_cd.Location = New System.Drawing.Point(5, 48)
        Me.bs_cd.Name = "bs_cd"
        Me.bs_cd.Size = New System.Drawing.Size(195, 24)
        Me.bs_cd.TabIndex = 2
        Me.bs_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bs_cd.Title = "bs_cd"
        Me.bs_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bs_cd.TitleWidth = 80
        '
        'co_cd
        '
        Me.co_cd.Location = New System.Drawing.Point(5, 25)
        Me.co_cd.Name = "co_cd"
        Me.co_cd.Size = New System.Drawing.Size(195, 24)
        Me.co_cd.TabIndex = 2
        Me.co_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.co_cd.Title = "co_cd"
        Me.co_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.co_cd.TitleWidth = 80
        '
        'EPanel3
        '
        Me.EPanel3.Controls.Add(Me.g10)
        Me.EPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel3.Location = New System.Drawing.Point(0, 0)
        Me.EPanel3.Name = "EPanel3"
        Me.EPanel3.Size = New System.Drawing.Size(407, 638)
        Me.EPanel3.TabIndex = 0
        Me.EPanel3.Text = "     PO List"
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(2, 26)
        Me.g10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.g10.Name = "g10"
        Me.g10.Size = New System.Drawing.Size(403, 610)
        Me.g10.TabIndex = 5
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.EPanel4)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.EPanel1)
        Me.SplitContainer1.Size = New System.Drawing.Size(1206, 765)
        Me.SplitContainer1.SplitterDistance = 148
        Me.SplitContainer1.TabIndex = 5
        '
        'EPanel4
        '
        Me.EPanel4.Controls.Add(Me.btn_pi)
        Me.EPanel4.Controls.Add(Me.pay_term)
        Me.EPanel4.Controls.Add(Me.income_term)
        Me.EPanel4.Controls.Add(Me.pod)
        Me.EPanel4.Controls.Add(Me.pol)
        Me.EPanel4.Controls.Add(Me.dest_cd)
        Me.EPanel4.Controls.Add(Me.status)
        Me.EPanel4.Controls.Add(Me.ship_dt)
        Me.EPanel4.Controls.Add(Me.pi_dt)
        Me.EPanel4.Controls.Add(Me.consignee)
        Me.EPanel4.Controls.Add(Me.rmks)
        Me.EPanel4.Controls.Add(Me.packing)
        Me.EPanel4.Controls.Add(Me.shipper)
        Me.EPanel4.Controls.Add(Me.po_no)
        Me.EPanel4.Controls.Add(Me.manu_cd)
        Me.EPanel4.Controls.Add(Me.pi_no)
        Me.EPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel4.Location = New System.Drawing.Point(0, 0)
        Me.EPanel4.Name = "EPanel4"
        Me.EPanel4.Size = New System.Drawing.Size(1206, 148)
        Me.EPanel4.TabIndex = 4
        Me.EPanel4.Text = "     Export Master"
        '
        'btn_pi
        '
        Me.btn_pi.Location = New System.Drawing.Point(8, 120)
        Me.btn_pi.Name = "btn_pi"
        Me.btn_pi.Size = New System.Drawing.Size(95, 26)
        Me.btn_pi.TabIndex = 5
        Me.btn_pi.Text = "Print PI"
        '
        'pay_term
        '
        Me.pay_term.Location = New System.Drawing.Point(208, 72)
        Me.pay_term.Name = "pay_term"
        Me.pay_term.Size = New System.Drawing.Size(197, 24)
        Me.pay_term.TabIndex = 4
        Me.pay_term.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pay_term.Title = "payment_term"
        Me.pay_term.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pay_term.TitleWidth = 80
        '
        'income_term
        '
        Me.income_term.Location = New System.Drawing.Point(411, 24)
        Me.income_term.Name = "income_term"
        Me.income_term.Size = New System.Drawing.Size(197, 24)
        Me.income_term.TabIndex = 4
        Me.income_term.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.income_term.Title = "income_term"
        Me.income_term.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.income_term.TitleWidth = 80
        '
        'pod
        '
        Me.pod.Location = New System.Drawing.Point(411, 72)
        Me.pod.Name = "pod"
        Me.pod.Size = New System.Drawing.Size(197, 24)
        Me.pod.TabIndex = 4
        Me.pod.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pod.Title = "pod"
        Me.pod.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pod.TitleWidth = 80
        '
        'pol
        '
        Me.pol.Location = New System.Drawing.Point(411, 48)
        Me.pol.Name = "pol"
        Me.pol.Size = New System.Drawing.Size(197, 24)
        Me.pol.TabIndex = 4
        Me.pol.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pol.Title = "pol"
        Me.pol.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pol.TitleWidth = 80
        '
        'dest_cd
        '
        Me.dest_cd.Location = New System.Drawing.Point(612, 24)
        Me.dest_cd.Name = "dest_cd"
        Me.dest_cd.Size = New System.Drawing.Size(197, 24)
        Me.dest_cd.TabIndex = 4
        Me.dest_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.dest_cd.Title = "dest_cd"
        Me.dest_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.dest_cd.TitleWidth = 80
        '
        'status
        '
        Me.status.Location = New System.Drawing.Point(612, 72)
        Me.status.Name = "status"
        Me.status.Size = New System.Drawing.Size(197, 24)
        Me.status.TabIndex = 4
        Me.status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.status.Title = "status"
        Me.status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.status.TitleWidth = 80
        '
        'ship_dt
        '
        Me.ship_dt.Location = New System.Drawing.Point(612, 48)
        Me.ship_dt.Name = "ship_dt"
        Me.ship_dt.Size = New System.Drawing.Size(197, 24)
        Me.ship_dt.TabIndex = 3
        Me.ship_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ship_dt.Title = "shipt_dt"
        Me.ship_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ship_dt.TitleWidth = 80
        '
        'pi_dt
        '
        Me.pi_dt.Location = New System.Drawing.Point(5, 48)
        Me.pi_dt.Name = "pi_dt"
        Me.pi_dt.Size = New System.Drawing.Size(197, 24)
        Me.pi_dt.TabIndex = 3
        Me.pi_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pi_dt.Title = "pi_dt"
        Me.pi_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pi_dt.TitleWidth = 80
        '
        'consignee
        '
        Me.consignee.Location = New System.Drawing.Point(209, 169)
        Me.consignee.Name = "consignee"
        Me.consignee.Size = New System.Drawing.Size(197, 24)
        Me.consignee.TabIndex = 2
        Me.consignee.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.consignee.Title = "consignee"
        Me.consignee.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.consignee.TitleWidth = 80
        '
        'rmks
        '
        Me.rmks.Location = New System.Drawing.Point(5, 96)
        Me.rmks.Name = "rmks"
        Me.rmks.Size = New System.Drawing.Size(803, 24)
        Me.rmks.TabIndex = 2
        Me.rmks.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rmks.Title = "rmks"
        Me.rmks.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rmks.TitleWidth = 80
        '
        'packing
        '
        Me.packing.Location = New System.Drawing.Point(208, 48)
        Me.packing.Name = "packing"
        Me.packing.Size = New System.Drawing.Size(197, 24)
        Me.packing.TabIndex = 2
        Me.packing.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.packing.Title = "packing"
        Me.packing.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.packing.TitleWidth = 80
        '
        'shipper
        '
        Me.shipper.Location = New System.Drawing.Point(6, 169)
        Me.shipper.Name = "shipper"
        Me.shipper.Size = New System.Drawing.Size(197, 24)
        Me.shipper.TabIndex = 2
        Me.shipper.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.shipper.Title = "shipper"
        Me.shipper.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.shipper.TitleWidth = 80
        '
        'po_no
        '
        Me.po_no.Location = New System.Drawing.Point(208, 24)
        Me.po_no.Name = "po_no"
        Me.po_no.Size = New System.Drawing.Size(197, 24)
        Me.po_no.TabIndex = 2
        Me.po_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.po_no.Title = "po_no"
        Me.po_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.po_no.TitleWidth = 80
        '
        'manu_cd
        '
        Me.manu_cd.Location = New System.Drawing.Point(5, 72)
        Me.manu_cd.Name = "manu_cd"
        Me.manu_cd.Size = New System.Drawing.Size(197, 24)
        Me.manu_cd.TabIndex = 2
        Me.manu_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.manu_cd.Title = "ivc_no"
        Me.manu_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.manu_cd.TitleWidth = 80
        '
        'pi_no
        '
        Me.pi_no.Location = New System.Drawing.Point(5, 24)
        Me.pi_no.Name = "pi_no"
        Me.pi_no.Size = New System.Drawing.Size(197, 24)
        Me.pi_no.TabIndex = 2
        Me.pi_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pi_no.Title = "pi_no"
        Me.pi_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pi_no.TitleWidth = 80
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.g20)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(1206, 613)
        Me.EPanel1.TabIndex = 0
        Me.EPanel1.Text = "     Detail"
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(2, 26)
        Me.g20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.g20.Name = "g20"
        Me.g20.Size = New System.Drawing.Size(1202, 585)
        Me.g20.TabIndex = 2
        '
        'MMD700
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SplitContainer2)
        Me.Name = "MMD700"
        Me.Size = New System.Drawing.Size(1617, 765)
        Me.Controls.SetChildIndex(Me.SplitContainer2, 0)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel2.ResumeLayout(False)
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel3.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel4.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel2 As Frame8.ePanel
    Friend WithEvents f_pi_no As Frame8.eText
    Friend WithEvents f_po_no As Frame8.eText
    Friend WithEvents f_buyer As Frame8.eText
    Friend WithEvents f_manu As Frame8.eText
    Friend WithEvents to_dt As Frame8.eDate
    Friend WithEvents fr_dt As Frame8.eDate
    Friend WithEvents wh_cd As Frame8.eCombo
    Friend WithEvents bs_cd As Frame8.eCombo
    Friend WithEvents co_cd As Frame8.eCombo
    Friend WithEvents EPanel3 As Frame8.ePanel
    Friend WithEvents g10 As Frame8.eGrid
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel4 As Frame8.ePanel
    Friend WithEvents pod As Frame8.eCombo
    Friend WithEvents pol As Frame8.eCombo
    Friend WithEvents dest_cd As Frame8.eCombo
    Friend WithEvents status As Frame8.eCombo
    Friend WithEvents pi_dt As Frame8.eDate
    Friend WithEvents po_no As Frame8.eText
    Friend WithEvents pi_no As Frame8.eText
    Friend WithEvents income_term As Frame8.eCombo
    Friend WithEvents rmks As Frame8.eText
    Friend WithEvents packing As Frame8.eText
    Friend WithEvents manu_cd As Frame8.eText
    Friend WithEvents consignee As Frame8.eText
    Friend WithEvents shipper As Frame8.eText
    Friend WithEvents btn_pi As Frame8.eButton
    Friend WithEvents EPanel1 As Frame8.ePanel
    Friend WithEvents g20 As Frame8.eGrid
    Friend WithEvents pay_term As Frame8.eCombo
    Friend WithEvents ship_dt As Frame8.eDate

End Class
