﻿Imports Frame8
Imports Base8
Imports Base8.Shared
Imports System.Data

Public Class MMD950
    Private Sub MMD900_Load(sender As Object, e As EventArgs) Handles Me.Load
        insp_no.CodeNo = "MMD950"
        insp_no.CodeDateField = insp_dt
    End Sub
    Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)

        Select Case mty

            Case MenuType.Save
                If Me.Save Then
                    PutMessage("SYS_SAVE", "Save Success.")
                    Me.Open()
                End If
                'Case MenuType.New
                '    req_no.Text = ""
                '    Me.OpenTrigger("LER100_g10")
                'Case MenuType.Save
                '    If Me.Save Then
                '        Me.Open()
                '    End If
                'Case MenuType.Delete
                '    Delete("LER100_f10")
            Case Else

                MyBase.MenuButton_Click(mty)

        End Select

    End Sub

    Private Sub btn_app_Click(sender As Object, e As EventArgs) Handles btn_app.Click
        Dim p As OpenParameters = New OpenParameters

        p.Add("@insp_no", insp_no.Text)

        Dim dset As DataSet = OpenDataSet("mmd950_app", p)

    End Sub
End Class
