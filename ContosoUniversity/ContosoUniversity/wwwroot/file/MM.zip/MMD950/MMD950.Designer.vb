﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MMD950
    Inherits Base8.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.EPanel2 = New Frame8.ePanel()
        Me.f_ship_no = New Frame8.eText()
        Me.f_insp_no = New Frame8.eText()
        Me.f_supplier_cd = New Frame8.eText()
        Me.f_supplier_nm = New Frame8.eText()
        Me.f_status = New Frame8.eCheckCombo()
        Me.f_dest_cd = New Frame8.eCombo()
        Me.to_dt = New Frame8.eDate()
        Me.fr_dt = New Frame8.eDate()
        Me.bs_cd = New Frame8.eCombo()
        Me.co_cd = New Frame8.eCombo()
        Me.EPanel3 = New Frame8.ePanel()
        Me.g10 = New Frame8.eGrid()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer4 = New System.Windows.Forms.SplitContainer()
        Me.EPanel5 = New Frame8.ePanel()
        Me.ship_no = New Frame8.eText()
        Me.insp_no = New Frame8.eText()
        Me.insp_dt = New Frame8.eDate()
        Me.rmks = New Frame8.eText()
        Me.status = New Frame8.eCombo()
        Me.EPanel4 = New Frame8.ePanel()
        Me.g20 = New Frame8.eGrid()
        Me.EPanel1 = New Frame8.ePanel()
        Me.g30 = New Frame8.eGrid()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.btn_app = New Frame8.eButton()
        Me.app_yn = New Frame8.eCheck()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel2.SuspendLayout()
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel3.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SplitContainer4.Panel1.SuspendLayout()
        Me.SplitContainer4.Panel2.SuspendLayout()
        Me.SplitContainer4.SuspendLayout()
        CType(Me.EPanel5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel5.SuspendLayout()
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel4.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.EPanel2)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.EPanel3)
        Me.SplitContainer3.Size = New System.Drawing.Size(459, 581)
        Me.SplitContainer3.SplitterDistance = 142
        Me.SplitContainer3.TabIndex = 2
        '
        'EPanel2
        '
        Me.EPanel2.Controls.Add(Me.f_ship_no)
        Me.EPanel2.Controls.Add(Me.f_insp_no)
        Me.EPanel2.Controls.Add(Me.f_supplier_cd)
        Me.EPanel2.Controls.Add(Me.f_supplier_nm)
        Me.EPanel2.Controls.Add(Me.f_status)
        Me.EPanel2.Controls.Add(Me.f_dest_cd)
        Me.EPanel2.Controls.Add(Me.to_dt)
        Me.EPanel2.Controls.Add(Me.fr_dt)
        Me.EPanel2.Controls.Add(Me.bs_cd)
        Me.EPanel2.Controls.Add(Me.co_cd)
        Me.EPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel2.Location = New System.Drawing.Point(0, 0)
        Me.EPanel2.Name = "EPanel2"
        Me.EPanel2.Size = New System.Drawing.Size(459, 142)
        Me.EPanel2.TabIndex = 4
        Me.EPanel2.Text = "     Serch"
        '
        'f_ship_no
        '
        Me.f_ship_no.Location = New System.Drawing.Point(231, 94)
        Me.f_ship_no.Name = "f_ship_no"
        Me.f_ship_no.Size = New System.Drawing.Size(220, 20)
        Me.f_ship_no.TabIndex = 37
        Me.f_ship_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_ship_no.Title = "f_ship_no"
        Me.f_ship_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_ship_no.TitleWidth = 90
        '
        'f_insp_no
        '
        Me.f_insp_no.Location = New System.Drawing.Point(231, 71)
        Me.f_insp_no.Name = "f_insp_no"
        Me.f_insp_no.Size = New System.Drawing.Size(220, 20)
        Me.f_insp_no.TabIndex = 37
        Me.f_insp_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_insp_no.Title = "f_insp_no"
        Me.f_insp_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_insp_no.TitleWidth = 90
        '
        'f_supplier_cd
        '
        Me.f_supplier_cd.Location = New System.Drawing.Point(5, 153)
        Me.f_supplier_cd.Name = "f_supplier_cd"
        Me.f_supplier_cd.Size = New System.Drawing.Size(240, 20)
        Me.f_supplier_cd.TabIndex = 37
        Me.f_supplier_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_supplier_cd.Title = "f_supplier_cd"
        Me.f_supplier_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        '
        'f_supplier_nm
        '
        Me.f_supplier_nm.Location = New System.Drawing.Point(5, 71)
        Me.f_supplier_nm.Name = "f_supplier_nm"
        Me.f_supplier_nm.Size = New System.Drawing.Size(220, 20)
        Me.f_supplier_nm.TabIndex = 37
        Me.f_supplier_nm.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_supplier_nm.Title = "f_supplier_nm"
        Me.f_supplier_nm.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_supplier_nm.TitleWidth = 90
        '
        'f_status
        '
        Me.f_status.Location = New System.Drawing.Point(5, 117)
        Me.f_status.Name = "f_status"
        Me.f_status.Size = New System.Drawing.Size(220, 20)
        Me.f_status.TabIndex = 35
        Me.f_status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_status.Title = "f_status"
        Me.f_status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_status.TitleWidth = 90
        '
        'f_dest_cd
        '
        Me.f_dest_cd.Location = New System.Drawing.Point(5, 94)
        Me.f_dest_cd.Name = "f_dest_cd"
        Me.f_dest_cd.Size = New System.Drawing.Size(220, 20)
        Me.f_dest_cd.TabIndex = 34
        Me.f_dest_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_dest_cd.Title = "f_dest_cd"
        Me.f_dest_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_dest_cd.TitleWidth = 90
        '
        'to_dt
        '
        Me.to_dt.Location = New System.Drawing.Point(231, 48)
        Me.to_dt.Name = "to_dt"
        Me.to_dt.Size = New System.Drawing.Size(220, 20)
        Me.to_dt.TabIndex = 30
        Me.to_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.to_dt.Title = "to_dt"
        Me.to_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.to_dt.TitleWidth = 90
        '
        'fr_dt
        '
        Me.fr_dt.Location = New System.Drawing.Point(231, 25)
        Me.fr_dt.Name = "fr_dt"
        Me.fr_dt.Size = New System.Drawing.Size(220, 20)
        Me.fr_dt.TabIndex = 31
        Me.fr_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.fr_dt.Title = "fr_dt"
        Me.fr_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.fr_dt.TitleWidth = 90
        '
        'bs_cd
        '
        Me.bs_cd.Location = New System.Drawing.Point(5, 48)
        Me.bs_cd.Name = "bs_cd"
        Me.bs_cd.Size = New System.Drawing.Size(220, 20)
        Me.bs_cd.TabIndex = 29
        Me.bs_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bs_cd.Title = "bs_cd"
        Me.bs_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bs_cd.TitleWidth = 90
        '
        'co_cd
        '
        Me.co_cd.Location = New System.Drawing.Point(5, 25)
        Me.co_cd.Name = "co_cd"
        Me.co_cd.Size = New System.Drawing.Size(220, 20)
        Me.co_cd.TabIndex = 28
        Me.co_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.co_cd.Title = "co_cd"
        Me.co_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.co_cd.TitleWidth = 90
        '
        'EPanel3
        '
        Me.EPanel3.Controls.Add(Me.g10)
        Me.EPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel3.Location = New System.Drawing.Point(0, 0)
        Me.EPanel3.Name = "EPanel3"
        Me.EPanel3.Size = New System.Drawing.Size(459, 435)
        Me.EPanel3.TabIndex = 0
        Me.EPanel3.Text = "     List"
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(2, 22)
        Me.g10.Name = "g10"
        Me.g10.Size = New System.Drawing.Size(455, 411)
        Me.g10.TabIndex = 2
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer4)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.EPanel1)
        Me.SplitContainer1.Size = New System.Drawing.Size(941, 581)
        Me.SplitContainer1.SplitterDistance = 294
        Me.SplitContainer1.TabIndex = 5
        '
        'SplitContainer4
        '
        Me.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer4.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer4.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer4.Name = "SplitContainer4"
        Me.SplitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer4.Panel1
        '
        Me.SplitContainer4.Panel1.Controls.Add(Me.EPanel5)
        '
        'SplitContainer4.Panel2
        '
        Me.SplitContainer4.Panel2.Controls.Add(Me.EPanel4)
        Me.SplitContainer4.Size = New System.Drawing.Size(941, 294)
        Me.SplitContainer4.SplitterDistance = 73
        Me.SplitContainer4.TabIndex = 5
        '
        'EPanel5
        '
        Me.EPanel5.Controls.Add(Me.app_yn)
        Me.EPanel5.Controls.Add(Me.btn_app)
        Me.EPanel5.Controls.Add(Me.ship_no)
        Me.EPanel5.Controls.Add(Me.insp_no)
        Me.EPanel5.Controls.Add(Me.insp_dt)
        Me.EPanel5.Controls.Add(Me.rmks)
        Me.EPanel5.Controls.Add(Me.status)
        Me.EPanel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel5.Location = New System.Drawing.Point(0, 0)
        Me.EPanel5.Name = "EPanel5"
        Me.EPanel5.Size = New System.Drawing.Size(941, 73)
        Me.EPanel5.TabIndex = 5
        Me.EPanel5.Text = "     Inspection"
        '
        'ship_no
        '
        Me.ship_no.Location = New System.Drawing.Point(683, 48)
        Me.ship_no.Name = "ship_no"
        Me.ship_no.Size = New System.Drawing.Size(264, 20)
        Me.ship_no.TabIndex = 37
        Me.ship_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ship_no.Title = "ship_no"
        Me.ship_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ship_no.TitleWidth = 90
        '
        'insp_no
        '
        Me.insp_no.Location = New System.Drawing.Point(5, 25)
        Me.insp_no.Name = "insp_no"
        Me.insp_no.Size = New System.Drawing.Size(220, 20)
        Me.insp_no.TabIndex = 37
        Me.insp_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.insp_no.Title = "insp_no"
        Me.insp_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.insp_no.TitleWidth = 90
        '
        'insp_dt
        '
        Me.insp_dt.Location = New System.Drawing.Point(231, 25)
        Me.insp_dt.Name = "insp_dt"
        Me.insp_dt.Size = New System.Drawing.Size(220, 20)
        Me.insp_dt.TabIndex = 31
        Me.insp_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.insp_dt.Title = "insp_dt"
        Me.insp_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.insp_dt.TitleWidth = 90
        '
        'rmks
        '
        Me.rmks.Location = New System.Drawing.Point(5, 48)
        Me.rmks.Name = "rmks"
        Me.rmks.Size = New System.Drawing.Size(446, 20)
        Me.rmks.TabIndex = 37
        Me.rmks.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rmks.Title = "rmks"
        Me.rmks.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.rmks.TitleWidth = 90
        '
        'status
        '
        Me.status.Location = New System.Drawing.Point(457, 25)
        Me.status.Name = "status"
        Me.status.Size = New System.Drawing.Size(220, 20)
        Me.status.TabIndex = 34
        Me.status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.status.Title = "status"
        Me.status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.status.TitleWidth = 90
        '
        'EPanel4
        '
        Me.EPanel4.Controls.Add(Me.g20)
        Me.EPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel4.Location = New System.Drawing.Point(0, 0)
        Me.EPanel4.Name = "EPanel4"
        Me.EPanel4.Size = New System.Drawing.Size(941, 217)
        Me.EPanel4.TabIndex = 4
        Me.EPanel4.Text = "     Detail"
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(2, 22)
        Me.g20.Name = "g20"
        Me.g20.Size = New System.Drawing.Size(937, 193)
        Me.g20.TabIndex = 3
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.g30)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(941, 283)
        Me.EPanel1.TabIndex = 5
        Me.EPanel1.Text = "     Inspection Reason"
        '
        'g30
        '
        Me.g30.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g30.Location = New System.Drawing.Point(2, 22)
        Me.g30.Name = "g30"
        Me.g30.Size = New System.Drawing.Size(937, 259)
        Me.g30.TabIndex = 3
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.SplitContainer3)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer1)
        Me.SplitContainer2.Size = New System.Drawing.Size(1404, 581)
        Me.SplitContainer2.SplitterDistance = 459
        Me.SplitContainer2.TabIndex = 3
        '
        'btn_app
        '
        Me.btn_app.Location = New System.Drawing.Point(683, 25)
        Me.btn_app.Name = "btn_app"
        Me.btn_app.Size = New System.Drawing.Size(86, 23)
        Me.btn_app.TabIndex = 38
        Me.btn_app.Text = "Approval"
        '
        'app_yn
        '
        Me.app_yn.Location = New System.Drawing.Point(458, 48)
        Me.app_yn.Name = "app_yn"
        Me.app_yn.Size = New System.Drawing.Size(219, 21)
        Me.app_yn.TabIndex = 39
        Me.app_yn.Title = "app_yn"
        Me.app_yn.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.app_yn.TitleWidth = 90
        '
        'MMD950
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SplitContainer2)
        Me.Name = "MMD950"
        Me.Size = New System.Drawing.Size(1404, 581)
        Me.Controls.SetChildIndex(Me.SplitContainer2, 0)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel2.ResumeLayout(False)
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel3.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer4.Panel1.ResumeLayout(False)
        Me.SplitContainer4.Panel2.ResumeLayout(False)
        Me.SplitContainer4.ResumeLayout(False)
        CType(Me.EPanel5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel5.ResumeLayout(False)
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel4.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel2 As Frame8.ePanel
    Friend WithEvents f_status As Frame8.eCheckCombo
    Friend WithEvents to_dt As Frame8.eDate
    Friend WithEvents fr_dt As Frame8.eDate
    Friend WithEvents bs_cd As Frame8.eCombo
    Friend WithEvents co_cd As Frame8.eCombo
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel4 As Frame8.ePanel
    Friend WithEvents EPanel1 As Frame8.ePanel
    Friend WithEvents EPanel3 As Frame8.ePanel
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents f_ship_no As Frame8.eText
    Friend WithEvents f_insp_no As Frame8.eText
    Friend WithEvents f_supplier_cd As Frame8.eText
    Friend WithEvents f_supplier_nm As Frame8.eText
    Friend WithEvents f_dest_cd As Frame8.eCombo
    Friend WithEvents g10 As Frame8.eGrid
    Friend WithEvents SplitContainer4 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel5 As Frame8.ePanel
    Friend WithEvents insp_no As Frame8.eText
    Friend WithEvents insp_dt As Frame8.eDate
    Friend WithEvents rmks As Frame8.eText
    Friend WithEvents status As Frame8.eCombo
    Friend WithEvents g20 As Frame8.eGrid
    Friend WithEvents g30 As Frame8.eGrid
    Friend WithEvents ship_no As Frame8.eText
    Friend WithEvents btn_app As Frame8.eButton
    Friend WithEvents app_yn As Frame8.eCheck

End Class
