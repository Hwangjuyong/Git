﻿Imports Frame8
Imports Base8
Imports Base8.Shared

Public Class MMD850
    Private Sub MMD850_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)

        Select Case mty

            Case MenuType.Save
                If Me.Save Then
                    PutMessage("SYS_SAVE", "Save Success.")
                    Me.Open()
                End If
                'Case MenuType.New
                '    req_no.Text = ""
                '    Me.OpenTrigger("LER100_g10")
                'Case MenuType.Save
                '    If Me.Save Then
                '        Me.Open()
                '    End If
                'Case MenuType.Delete
                '    Delete("LER100_f10")
            Case Else

                MyBase.MenuButton_Click(mty)

        End Select

    End Sub

    Private Sub g30_DoubleClick(sender As Object, e As EventArgs) Handles g30.DoubleClick
        g40.AllowInsertRows = True
        g40.AddNewRow()

        g40.Text("ship_no") = g20.Text("ship_no")
        g40.Text("ship_sq") = g20.Text("seq")
        g40.Text("po_no") = g30.Text("po_no")
        g40.Text("po_sq") = g30.Text("po_sq")
        g40.Text("itm_id") = g20.Text("itm_id")
        g40.Text("po_qty") = g30.Text("qty")
        g40.Text("ship_qty") = g20.Text("qty")
        g40.Text("insp_qty") = g20.Text("qty")

        g40.AllowInsertRows = False
    End Sub
End Class
