Imports Frame8
Imports Base8
Imports Base8.Shared


Public Class MMD800
    Private Sub LEA311_Load(sender As Object, e As EventArgs) Handles Me.Load
        ship_no.CodeNo = "MMD800"
        ship_no.CodeDateField = ship_dt

        Init_Form()
    End Sub

    Public Sub Init_Form()
        'FTP Upload��
        g30.AllowDrop = True

        'Drag & Drop���� �� �ű����� �߰�����
        'Grid�� ���� �������θ� ���� ����
        g30.AllowAddRows = False    'Drag & Drop���� �� �ű����� �߰�����
        g30.AllowDeleteRows = False '���Ƿ� DB������ �����Ǹ� FTP���� ����ȭ�� ��������

        g10.RecordNavigator = True
        g20.RecordNavigator = True
        g30.RecordNavigator = True
    End Sub
   


    Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)

        Select Case mty

            Case MenuType.Save
                If Me.Save Then
                    PutMessage("SYS_SAVE", "Save Success.")
                    Me.Open()
                End If
            Case MenuType.New
                ship_no.Text = ""
                Me.OpenTrigger("MMD800_g10")
                
            Case MenuType.Delete
                Delete("MMD800_f10")
                Me.Open()
            Case Else

                MyBase.MenuButton_Click(mty)

        End Select

    End Sub


#Region "FTP"
    Private Sub g30_ButtonPressed(sender As Object, columnName As String) Handles g30.ButtonPressed
        Dim fileID As String = g30.Text("file_id")
        Dim fileNm As String = g30.Text("file_nm")
        If fileNm = "" Then
            Exit Sub
        End If

        If columnName = "del" Then
            Try
                'If FTP.FileDelete(fileID, fileNm) = True Then
                ' ��������: fileID �� ��� �� �����ǰ� �ؾ��Ѵ�
                If fileID = "" OrElse FTPShared.FileDelete(fileID, fileNm) = True Then
                    g30.AllowDeleteRows = True
                    g30.DeleteSelectedRows()
                    g30.AllowDeleteRows = False

                    Me.Save(g30.WorkSet)
                End If
            Catch ex As Exception
                MessageInfo(ex)
            End Try

        End If

        If columnName = "show" Then
            FTPShared.FileDownLoad(fileID, fileNm, , True)
        End If

        If columnName = "down" Then
            FTPShared.FileDownLoad(fileID, fileNm)
        End If
    End Sub

    Private Sub g30_DragDrop(sender As Object, e As System.Windows.Forms.DragEventArgs) Handles g30.DragDrop
        If e.Data.GetDataPresent(DataFormats.FileDrop.ToString) Then

            If Not MyBase.Save() Then
                Exit Sub
            End If

            'Grid�� ���� File�� üũ 
            For Each fileNm As String In e.Data.GetData(DataFormats.FileDrop)
                fileNm = System.IO.Path.GetFileName(fileNm)
                If Me._IsExists(g30, fileNm) Then
                    'If MessageYesNo("�̹� ���� ���ϸ��� ���� ������ �����մϴ�." + vbLf + vbLf + _
                    '                "�׷��� Upload �Ͻðڽ��ϱ� ?" + vbLf + vbLf + "[" + fileNm + "]") = MsgBoxResult.No Then
                    '    Exit Sub
                    'End If
                    If PutYesNo("GAM100_01", "�̹� ���� ���ϸ��� ���� ������ �����մϴ�.<br><br>�׷��� Upload �Ͻðڽ��ϱ� ?<br><br>[@1]", fileNm) = MsgBoxResult.No Then
                        Exit Sub
                    End If
                End If
            Next

            'Grid�� �������� �߰�
            Dim fullPath As String
            g30.AllowAddRows = True
            For Each fullPath In e.Data.GetData(DataFormats.FileDrop)

                Dim FileID As String = FTPShared.FileUpload("", fullPath)
                'If fullPath <> "" Then
                ' ��������: fileID �� ����� ���� �ȵǰ� �ؾ��Ѵ�
                If FileID <> "" And fullPath <> "" Then

                    '���ϸ��� �и�
                    Dim fileNm As String = System.IO.Path.GetFileName(fullPath)

                    Dim f As New System.IO.FileInfo(fullPath)
                    g30.AddNewRow()
                    g30.Text("file_id") = FileID
                    g30.Text("file_nm") = fileNm
                    g30.Text("file_size") = f.Length.ToString
                End If

            Next
            g30.AllowAddRows = False

            Me.Save(g30.WorkSet)
            g30.Open()
        End If
    End Sub

    Private Sub g30_DragOver(sender As Object, e As System.Windows.Forms.DragEventArgs) Handles g30.DragOver
        If e.Data.GetDataPresent(DataFormats.FileDrop.ToString) Then
            e.Effect = DragDropEffects.Copy
        End If
    End Sub

    Private Function _IsExists(ByVal g As eGrid, ByVal fileNm As String) As Boolean
        With g
            For i As Integer = 0 To .RowCount - 1
                If .Text("file_nm", i) = fileNm Then
                    Return True
                End If
            Next
        End With
        Return False
    End Function
#End Region

End Class
