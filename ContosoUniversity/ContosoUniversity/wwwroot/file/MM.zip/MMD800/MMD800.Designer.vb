<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MMD800
    Inherits Base8.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.EPanel2 = New Frame8.ePanel()
        Me.f_ship_no = New Frame8.eText()
        Me.f_cont_no = New Frame8.eText()
        Me.f_buyer = New Frame8.eText()
        Me.f_manu = New Frame8.eText()
        Me.to_dt = New Frame8.eDate()
        Me.fr_dt = New Frame8.eDate()
        Me.f_status = New Frame8.eCombo()
        Me.bs_cd = New Frame8.eCombo()
        Me.co_cd = New Frame8.eCombo()
        Me.EPanel3 = New Frame8.ePanel()
        Me.g10 = New Frame8.eGrid()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.EPanel4 = New Frame8.ePanel()
        Me.dest_cd = New Frame8.eCombo()
        Me.status = New Frame8.eCombo()
        Me.ship_dt = New Frame8.eDate()
        Me.consignee = New Frame8.eText()
        Me.port_loading = New Frame8.eText()
        Me.shipper = New Frame8.eText()
        Me.serial_no = New Frame8.eText()
        Me.ship_no = New Frame8.eText()
        Me.g20 = New Frame8.eGrid()
        Me.f_supp = New Frame8.eText()
        Me.etd = New Frame8.eDate()
        Me.eta = New Frame8.eDate()
        Me.vs_name = New Frame8.eText()
        Me.vs_origin = New Frame8.eText()
        Me.supplier = New Frame8.eText()
        Me.vs_ton = New Frame8.eText()
        Me.vs_capacity = New Frame8.eText()
        Me.vs_packstyle = New Frame8.eText()
        Me.vs_packcount = New Frame8.eText()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage1 = New DevExpress.XtraTab.XtraTabPage()
        Me.XtraTabPage2 = New DevExpress.XtraTab.XtraTabPage()
        Me.g30 = New Frame8.eGrid()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel2.SuspendLayout()
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel3.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel4.SuspendLayout()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.XtraTabPage1.SuspendLayout()
        Me.XtraTabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.SplitContainer3)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer1)
        Me.SplitContainer2.Size = New System.Drawing.Size(1617, 765)
        Me.SplitContainer2.SplitterDistance = 407
        Me.SplitContainer2.TabIndex = 4
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.EPanel2)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.EPanel3)
        Me.SplitContainer3.Size = New System.Drawing.Size(407, 765)
        Me.SplitContainer3.SplitterDistance = 150
        Me.SplitContainer3.TabIndex = 2
        '
        'EPanel2
        '
        Me.EPanel2.Controls.Add(Me.f_ship_no)
        Me.EPanel2.Controls.Add(Me.f_cont_no)
        Me.EPanel2.Controls.Add(Me.f_buyer)
        Me.EPanel2.Controls.Add(Me.f_manu)
        Me.EPanel2.Controls.Add(Me.to_dt)
        Me.EPanel2.Controls.Add(Me.dest_cd)
        Me.EPanel2.Controls.Add(Me.fr_dt)
        Me.EPanel2.Controls.Add(Me.f_status)
        Me.EPanel2.Controls.Add(Me.bs_cd)
        Me.EPanel2.Controls.Add(Me.co_cd)
        Me.EPanel2.Controls.Add(Me.f_supp)
        Me.EPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel2.Location = New System.Drawing.Point(0, 0)
        Me.EPanel2.Name = "EPanel2"
        Me.EPanel2.Size = New System.Drawing.Size(407, 150)
        Me.EPanel2.TabIndex = 4
        Me.EPanel2.Text = "     Serch"
        '
        'f_ship_no
        '
        Me.f_ship_no.Location = New System.Drawing.Point(206, 72)
        Me.f_ship_no.Name = "f_ship_no"
        Me.f_ship_no.Size = New System.Drawing.Size(195, 24)
        Me.f_ship_no.TabIndex = 4
        Me.f_ship_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_ship_no.Title = "f_ship_no"
        Me.f_ship_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_ship_no.TitleWidth = 80
        '
        'f_cont_no
        '
        Me.f_cont_no.Location = New System.Drawing.Point(206, 96)
        Me.f_cont_no.Name = "f_cont_no"
        Me.f_cont_no.Size = New System.Drawing.Size(195, 24)
        Me.f_cont_no.TabIndex = 4
        Me.f_cont_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_cont_no.Title = "f_cont_no"
        Me.f_cont_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_cont_no.TitleWidth = 80
        '
        'f_buyer
        '
        Me.f_buyer.Location = New System.Drawing.Point(5, 225)
        Me.f_buyer.Name = "f_buyer"
        Me.f_buyer.Size = New System.Drawing.Size(195, 24)
        Me.f_buyer.TabIndex = 4
        Me.f_buyer.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_buyer.Title = "f_buyer"
        Me.f_buyer.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_buyer.TitleWidth = 80
        '
        'f_manu
        '
        Me.f_manu.Location = New System.Drawing.Point(5, 202)
        Me.f_manu.Name = "f_manu"
        Me.f_manu.Size = New System.Drawing.Size(195, 24)
        Me.f_manu.TabIndex = 4
        Me.f_manu.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_manu.Title = "f_manu"
        Me.f_manu.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_manu.TitleWidth = 80
        '
        'to_dt
        '
        Me.to_dt.Location = New System.Drawing.Point(206, 48)
        Me.to_dt.Name = "to_dt"
        Me.to_dt.Size = New System.Drawing.Size(195, 24)
        Me.to_dt.TabIndex = 3
        Me.to_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.to_dt.Title = "to_dt"
        Me.to_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.to_dt.TitleWidth = 80
        '
        'fr_dt
        '
        Me.fr_dt.Location = New System.Drawing.Point(206, 25)
        Me.fr_dt.Name = "fr_dt"
        Me.fr_dt.Size = New System.Drawing.Size(195, 24)
        Me.fr_dt.TabIndex = 3
        Me.fr_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.fr_dt.Title = "fr_dt"
        Me.fr_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.fr_dt.TitleWidth = 80
        '
        'f_status
        '
        Me.f_status.Location = New System.Drawing.Point(5, 120)
        Me.f_status.Name = "f_status"
        Me.f_status.Size = New System.Drawing.Size(197, 24)
        Me.f_status.TabIndex = 2
        Me.f_status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_status.Title = "f_status"
        Me.f_status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_status.TitleWidth = 80
        '
        'bs_cd
        '
        Me.bs_cd.Location = New System.Drawing.Point(5, 48)
        Me.bs_cd.Name = "bs_cd"
        Me.bs_cd.Size = New System.Drawing.Size(197, 24)
        Me.bs_cd.TabIndex = 2
        Me.bs_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bs_cd.Title = "bs_cd"
        Me.bs_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bs_cd.TitleWidth = 80
        '
        'co_cd
        '
        Me.co_cd.Location = New System.Drawing.Point(5, 25)
        Me.co_cd.Name = "co_cd"
        Me.co_cd.Size = New System.Drawing.Size(197, 24)
        Me.co_cd.TabIndex = 2
        Me.co_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.co_cd.Title = "co_cd"
        Me.co_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.co_cd.TitleWidth = 80
        '
        'EPanel3
        '
        Me.EPanel3.Controls.Add(Me.g10)
        Me.EPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel3.Location = New System.Drawing.Point(0, 0)
        Me.EPanel3.Name = "EPanel3"
        Me.EPanel3.Size = New System.Drawing.Size(407, 611)
        Me.EPanel3.TabIndex = 0
        Me.EPanel3.Text = "     Shipping List"
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(2, 26)
        Me.g10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.g10.Name = "g10"
        Me.g10.Size = New System.Drawing.Size(403, 583)
        Me.g10.TabIndex = 5
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.EPanel4)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.XtraTabControl1)
        Me.SplitContainer1.Size = New System.Drawing.Size(1206, 765)
        Me.SplitContainer1.SplitterDistance = 123
        Me.SplitContainer1.TabIndex = 5
        '
        'EPanel4
        '
        Me.EPanel4.Controls.Add(Me.status)
        Me.EPanel4.Controls.Add(Me.eta)
        Me.EPanel4.Controls.Add(Me.etd)
        Me.EPanel4.Controls.Add(Me.ship_dt)
        Me.EPanel4.Controls.Add(Me.consignee)
        Me.EPanel4.Controls.Add(Me.vs_capacity)
        Me.EPanel4.Controls.Add(Me.vs_packcount)
        Me.EPanel4.Controls.Add(Me.vs_packstyle)
        Me.EPanel4.Controls.Add(Me.vs_ton)
        Me.EPanel4.Controls.Add(Me.supplier)
        Me.EPanel4.Controls.Add(Me.vs_origin)
        Me.EPanel4.Controls.Add(Me.vs_name)
        Me.EPanel4.Controls.Add(Me.port_loading)
        Me.EPanel4.Controls.Add(Me.shipper)
        Me.EPanel4.Controls.Add(Me.serial_no)
        Me.EPanel4.Controls.Add(Me.ship_no)
        Me.EPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel4.Location = New System.Drawing.Point(0, 0)
        Me.EPanel4.Name = "EPanel4"
        Me.EPanel4.Size = New System.Drawing.Size(1206, 123)
        Me.EPanel4.TabIndex = 4
        Me.EPanel4.Text = "     Shipping Master"
        '
        'dest_cd
        '
        Me.dest_cd.Location = New System.Drawing.Point(5, 96)
        Me.dest_cd.Name = "dest_cd"
        Me.dest_cd.Size = New System.Drawing.Size(197, 24)
        Me.dest_cd.TabIndex = 4
        Me.dest_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.dest_cd.Title = "dest_cd"
        Me.dest_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.dest_cd.TitleWidth = 80
        '
        'status
        '
        Me.status.Location = New System.Drawing.Point(616, 24)
        Me.status.Name = "status"
        Me.status.Size = New System.Drawing.Size(197, 24)
        Me.status.TabIndex = 4
        Me.status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.status.Title = "status"
        Me.status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.status.TitleWidth = 80
        '
        'ship_dt
        '
        Me.ship_dt.Location = New System.Drawing.Point(5, 48)
        Me.ship_dt.Name = "ship_dt"
        Me.ship_dt.Size = New System.Drawing.Size(197, 24)
        Me.ship_dt.TabIndex = 3
        Me.ship_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ship_dt.Title = "ship_dt"
        Me.ship_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ship_dt.TitleWidth = 80
        '
        'consignee
        '
        Me.consignee.Location = New System.Drawing.Point(209, 169)
        Me.consignee.Name = "consignee"
        Me.consignee.Size = New System.Drawing.Size(197, 24)
        Me.consignee.TabIndex = 2
        Me.consignee.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.consignee.Title = "consignee"
        Me.consignee.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.consignee.TitleWidth = 80
        '
        'port_loading
        '
        Me.port_loading.Location = New System.Drawing.Point(208, 48)
        Me.port_loading.Name = "port_loading"
        Me.port_loading.Size = New System.Drawing.Size(197, 24)
        Me.port_loading.TabIndex = 2
        Me.port_loading.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.port_loading.Title = "port_loading"
        Me.port_loading.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.port_loading.TitleWidth = 80
        '
        'shipper
        '
        Me.shipper.Location = New System.Drawing.Point(6, 169)
        Me.shipper.Name = "shipper"
        Me.shipper.Size = New System.Drawing.Size(197, 24)
        Me.shipper.TabIndex = 2
        Me.shipper.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.shipper.Title = "shipper"
        Me.shipper.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.shipper.TitleWidth = 80
        '
        'serial_no
        '
        Me.serial_no.Location = New System.Drawing.Point(208, 24)
        Me.serial_no.Name = "serial_no"
        Me.serial_no.Size = New System.Drawing.Size(197, 24)
        Me.serial_no.TabIndex = 2
        Me.serial_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.serial_no.Title = "serial_no"
        Me.serial_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.serial_no.TitleWidth = 80
        '
        'ship_no
        '
        Me.ship_no.Location = New System.Drawing.Point(5, 24)
        Me.ship_no.Name = "ship_no"
        Me.ship_no.Size = New System.Drawing.Size(197, 24)
        Me.ship_no.TabIndex = 2
        Me.ship_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ship_no.Title = "ship_no"
        Me.ship_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ship_no.TitleWidth = 80
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(0, 0)
        Me.g20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.g20.Name = "g20"
        Me.g20.Size = New System.Drawing.Size(1198, 604)
        Me.g20.TabIndex = 2
        '
        'f_supp
        '
        Me.f_supp.Location = New System.Drawing.Point(5, 72)
        Me.f_supp.Name = "f_supp"
        Me.f_supp.Size = New System.Drawing.Size(197, 24)
        Me.f_supp.TabIndex = 2
        Me.f_supp.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_supp.Title = "f_supp"
        Me.f_supp.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_supp.TitleWidth = 80
        '
        'etd
        '
        Me.etd.Location = New System.Drawing.Point(5, 72)
        Me.etd.Name = "etd"
        Me.etd.Size = New System.Drawing.Size(197, 24)
        Me.etd.TabIndex = 3
        Me.etd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.etd.Title = "etd"
        Me.etd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.etd.TitleWidth = 80
        '
        'eta
        '
        Me.eta.Location = New System.Drawing.Point(5, 96)
        Me.eta.Name = "eta"
        Me.eta.Size = New System.Drawing.Size(197, 24)
        Me.eta.TabIndex = 3
        Me.eta.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.eta.Title = "eta"
        Me.eta.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.eta.TitleWidth = 80
        '
        'vs_name
        '
        Me.vs_name.Location = New System.Drawing.Point(208, 72)
        Me.vs_name.Name = "vs_name"
        Me.vs_name.Size = New System.Drawing.Size(197, 24)
        Me.vs_name.TabIndex = 2
        Me.vs_name.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_name.Title = "vs_name"
        Me.vs_name.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_name.TitleWidth = 80
        '
        'vs_origin
        '
        Me.vs_origin.Location = New System.Drawing.Point(412, 24)
        Me.vs_origin.Name = "vs_origin"
        Me.vs_origin.Size = New System.Drawing.Size(197, 24)
        Me.vs_origin.TabIndex = 2
        Me.vs_origin.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_origin.Title = "vs_origin"
        Me.vs_origin.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_origin.TitleWidth = 80
        '
        'supplier
        '
        Me.supplier.Location = New System.Drawing.Point(412, 48)
        Me.supplier.Name = "supplier"
        Me.supplier.Size = New System.Drawing.Size(197, 24)
        Me.supplier.TabIndex = 2
        Me.supplier.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.supplier.Title = "supplier"
        Me.supplier.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.supplier.TitleWidth = 80
        '
        'vs_ton
        '
        Me.vs_ton.Location = New System.Drawing.Point(412, 72)
        Me.vs_ton.Name = "vs_ton"
        Me.vs_ton.Size = New System.Drawing.Size(197, 24)
        Me.vs_ton.TabIndex = 2
        Me.vs_ton.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_ton.Title = "vs_ton"
        Me.vs_ton.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_ton.TitleWidth = 80
        '
        'vs_capacity
        '
        Me.vs_capacity.Location = New System.Drawing.Point(412, 96)
        Me.vs_capacity.Name = "vs_capacity"
        Me.vs_capacity.Size = New System.Drawing.Size(197, 24)
        Me.vs_capacity.TabIndex = 2
        Me.vs_capacity.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_capacity.Title = "vs_capacity"
        Me.vs_capacity.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_capacity.TitleWidth = 80
        '
        'vs_packstyle
        '
        Me.vs_packstyle.Location = New System.Drawing.Point(616, 48)
        Me.vs_packstyle.Name = "vs_packstyle"
        Me.vs_packstyle.Size = New System.Drawing.Size(197, 24)
        Me.vs_packstyle.TabIndex = 2
        Me.vs_packstyle.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_packstyle.Title = "vs_packstyle"
        Me.vs_packstyle.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_packstyle.TitleWidth = 80
        '
        'vs_packcount
        '
        Me.vs_packcount.Location = New System.Drawing.Point(616, 72)
        Me.vs_packcount.Name = "vs_packcount"
        Me.vs_packcount.Size = New System.Drawing.Size(197, 24)
        Me.vs_packcount.TabIndex = 2
        Me.vs_packcount.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_packcount.Title = "vs_packcount"
        Me.vs_packcount.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_packcount.TitleWidth = 80
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.XtraTabPage1
        Me.XtraTabControl1.Size = New System.Drawing.Size(1206, 638)
        Me.XtraTabControl1.TabIndex = 0
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage1, Me.XtraTabPage2})
        '
        'XtraTabPage1
        '
        Me.XtraTabPage1.Controls.Add(Me.g20)
        Me.XtraTabPage1.Name = "XtraTabPage1"
        Me.XtraTabPage1.Size = New System.Drawing.Size(1198, 604)
        Me.XtraTabPage1.Text = "Detail"
        '
        'XtraTabPage2
        '
        Me.XtraTabPage2.Controls.Add(Me.g30)
        Me.XtraTabPage2.Name = "XtraTabPage2"
        Me.XtraTabPage2.Size = New System.Drawing.Size(1198, 579)
        Me.XtraTabPage2.Text = "File"
        '
        'g30
        '
        Me.g30.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g30.Location = New System.Drawing.Point(0, 0)
        Me.g30.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.g30.Name = "g30"
        Me.g30.Size = New System.Drawing.Size(1198, 579)
        Me.g30.TabIndex = 0
        '
        'MMD800
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SplitContainer2)
        Me.Name = "MMD800"
        Me.Size = New System.Drawing.Size(1617, 765)
        Me.Controls.SetChildIndex(Me.SplitContainer2, 0)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel2.ResumeLayout(False)
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel3.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel4.ResumeLayout(False)
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.XtraTabPage1.ResumeLayout(False)
        Me.XtraTabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel2 As Frame8.ePanel
    Friend WithEvents f_ship_no As Frame8.eText
    Friend WithEvents f_cont_no As Frame8.eText
    Friend WithEvents f_buyer As Frame8.eText
    Friend WithEvents f_manu As Frame8.eText
    Friend WithEvents to_dt As Frame8.eDate
    Friend WithEvents fr_dt As Frame8.eDate
    Friend WithEvents f_status As Frame8.eCombo
    Friend WithEvents bs_cd As Frame8.eCombo
    Friend WithEvents co_cd As Frame8.eCombo
    Friend WithEvents EPanel3 As Frame8.ePanel
    Friend WithEvents g10 As Frame8.eGrid
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel4 As Frame8.ePanel
    Friend WithEvents dest_cd As Frame8.eCombo
    Friend WithEvents status As Frame8.eCombo
    Friend WithEvents serial_no As Frame8.eText
    Friend WithEvents ship_no As Frame8.eText
    Friend WithEvents port_loading As Frame8.eText
    Friend WithEvents consignee As Frame8.eText
    Friend WithEvents shipper As Frame8.eText
    Friend WithEvents g20 As Frame8.eGrid
    Friend WithEvents ship_dt As Frame8.eDate
    Friend WithEvents f_supp As Frame8.eText
    Friend WithEvents eta As Frame8.eDate
    Friend WithEvents etd As Frame8.eDate
    Friend WithEvents vs_capacity As Frame8.eText
    Friend WithEvents vs_packcount As Frame8.eText
    Friend WithEvents vs_packstyle As Frame8.eText
    Friend WithEvents vs_ton As Frame8.eText
    Friend WithEvents supplier As Frame8.eText
    Friend WithEvents vs_origin As Frame8.eText
    Friend WithEvents vs_name As Frame8.eText
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g30 As Frame8.eGrid

End Class
