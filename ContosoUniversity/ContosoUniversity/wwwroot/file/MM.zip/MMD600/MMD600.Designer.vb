﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MMD600
    Inherits Base8.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.EPanel2 = New Frame8.ePanel()
        Me.f_ivc_no = New Frame8.eText()
        Me.f_pi_no = New Frame8.eText()
        Me.f_ar_no = New Frame8.eText()
        Me.f_buyer = New Frame8.eText()
        Me.f_manu = New Frame8.eText()
        Me.f_cont_no = New Frame8.eText()
        Me.to_dt = New Frame8.eDate()
        Me.fr_dt = New Frame8.eDate()
        Me.f_status = New Frame8.eCombo()
        Me.wh_cd = New Frame8.eCombo()
        Me.bs_cd = New Frame8.eCombo()
        Me.co_cd = New Frame8.eCombo()
        Me.EPanel3 = New Frame8.ePanel()
        Me.g10 = New Frame8.eGrid()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.EPanel4 = New Frame8.ePanel()
        Me.dlv_term = New Frame8.eCombo()
        Me.pod = New Frame8.eCombo()
        Me.pol = New Frame8.eCombo()
        Me.dest_cd = New Frame8.eCombo()
        Me.status = New Frame8.eCombo()
        Me.board_dt = New Frame8.eDate()
        Me.ivc_dt = New Frame8.eDate()
        Me.cont_dt = New Frame8.eDate()
        Me.bl_no = New Frame8.eText()
        Me.consignee = New Frame8.eText()
        Me.consignee_nm = New Frame8.eText()
        Me.cbm = New Frame8.eText()
        Me.gross_wet = New Frame8.eText()
        Me.vessel = New Frame8.eText()
        Me.shipper = New Frame8.eText()
        Me.shipper_nm = New Frame8.eText()
        Me.ivc_no = New Frame8.eText()
        Me.cont_no = New Frame8.eText()
        Me.btn_cl = New Frame8.eButton()
        Me.btn_pl = New Frame8.eButton()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage1 = New DevExpress.XtraTab.XtraTabPage()
        Me.XtraTabPage2 = New DevExpress.XtraTab.XtraTabPage()
        Me.g30 = New Frame8.eGrid()
        Me.g20 = New Frame8.eGrid()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel2.SuspendLayout()
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel3.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel4.SuspendLayout()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.XtraTabPage1.SuspendLayout()
        Me.XtraTabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.SplitContainer3)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer1)
        Me.SplitContainer2.Size = New System.Drawing.Size(1313, 581)
        Me.SplitContainer2.SplitterDistance = 407
        Me.SplitContainer2.TabIndex = 4
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.EPanel2)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.EPanel3)
        Me.SplitContainer3.Size = New System.Drawing.Size(407, 581)
        Me.SplitContainer3.SplitterDistance = 143
        Me.SplitContainer3.TabIndex = 2
        '
        'EPanel2
        '
        Me.EPanel2.Controls.Add(Me.f_ivc_no)
        Me.EPanel2.Controls.Add(Me.f_pi_no)
        Me.EPanel2.Controls.Add(Me.f_ar_no)
        Me.EPanel2.Controls.Add(Me.f_buyer)
        Me.EPanel2.Controls.Add(Me.f_manu)
        Me.EPanel2.Controls.Add(Me.f_cont_no)
        Me.EPanel2.Controls.Add(Me.to_dt)
        Me.EPanel2.Controls.Add(Me.fr_dt)
        Me.EPanel2.Controls.Add(Me.f_status)
        Me.EPanel2.Controls.Add(Me.wh_cd)
        Me.EPanel2.Controls.Add(Me.bs_cd)
        Me.EPanel2.Controls.Add(Me.co_cd)
        Me.EPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel2.Location = New System.Drawing.Point(0, 0)
        Me.EPanel2.Name = "EPanel2"
        Me.EPanel2.Size = New System.Drawing.Size(407, 143)
        Me.EPanel2.TabIndex = 4
        Me.EPanel2.Text = "     Serch"
        '
        'f_ivc_no
        '
        Me.f_ivc_no.Location = New System.Drawing.Point(5, 117)
        Me.f_ivc_no.Name = "f_ivc_no"
        Me.f_ivc_no.Size = New System.Drawing.Size(195, 20)
        Me.f_ivc_no.TabIndex = 4
        Me.f_ivc_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_ivc_no.Title = "f_ivc_no"
        Me.f_ivc_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_ivc_no.TitleWidth = 80
        '
        'f_pi_no
        '
        Me.f_pi_no.Location = New System.Drawing.Point(206, 117)
        Me.f_pi_no.Name = "f_pi_no"
        Me.f_pi_no.Size = New System.Drawing.Size(195, 20)
        Me.f_pi_no.TabIndex = 4
        Me.f_pi_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_pi_no.Title = "f_pi_no"
        Me.f_pi_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_pi_no.TitleWidth = 80
        '
        'f_ar_no
        '
        Me.f_ar_no.Location = New System.Drawing.Point(206, 94)
        Me.f_ar_no.Name = "f_ar_no"
        Me.f_ar_no.Size = New System.Drawing.Size(195, 20)
        Me.f_ar_no.TabIndex = 4
        Me.f_ar_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_ar_no.Title = "f_ar_no"
        Me.f_ar_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_ar_no.TitleWidth = 80
        '
        'f_buyer
        '
        Me.f_buyer.Location = New System.Drawing.Point(5, 225)
        Me.f_buyer.Name = "f_buyer"
        Me.f_buyer.Size = New System.Drawing.Size(195, 20)
        Me.f_buyer.TabIndex = 4
        Me.f_buyer.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_buyer.Title = "f_buyer"
        Me.f_buyer.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_buyer.TitleWidth = 80
        '
        'f_manu
        '
        Me.f_manu.Location = New System.Drawing.Point(5, 202)
        Me.f_manu.Name = "f_manu"
        Me.f_manu.Size = New System.Drawing.Size(195, 20)
        Me.f_manu.TabIndex = 4
        Me.f_manu.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_manu.Title = "f_manu"
        Me.f_manu.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_manu.TitleWidth = 80
        '
        'f_cont_no
        '
        Me.f_cont_no.Location = New System.Drawing.Point(5, 94)
        Me.f_cont_no.Name = "f_cont_no"
        Me.f_cont_no.Size = New System.Drawing.Size(195, 20)
        Me.f_cont_no.TabIndex = 4
        Me.f_cont_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_cont_no.Title = "f_cont_no"
        Me.f_cont_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_cont_no.TitleWidth = 80
        '
        'to_dt
        '
        Me.to_dt.Location = New System.Drawing.Point(206, 48)
        Me.to_dt.Name = "to_dt"
        Me.to_dt.Size = New System.Drawing.Size(195, 20)
        Me.to_dt.TabIndex = 3
        Me.to_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.to_dt.Title = "to_dt"
        Me.to_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.to_dt.TitleWidth = 80
        '
        'fr_dt
        '
        Me.fr_dt.Location = New System.Drawing.Point(206, 25)
        Me.fr_dt.Name = "fr_dt"
        Me.fr_dt.Size = New System.Drawing.Size(195, 20)
        Me.fr_dt.TabIndex = 3
        Me.fr_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.fr_dt.Title = "fr_dt"
        Me.fr_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.fr_dt.TitleWidth = 80
        '
        'f_status
        '
        Me.f_status.Location = New System.Drawing.Point(206, 71)
        Me.f_status.Name = "f_status"
        Me.f_status.Size = New System.Drawing.Size(195, 20)
        Me.f_status.TabIndex = 2
        Me.f_status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_status.Title = "f_status"
        Me.f_status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_status.TitleWidth = 80
        '
        'wh_cd
        '
        Me.wh_cd.Location = New System.Drawing.Point(5, 71)
        Me.wh_cd.Name = "wh_cd"
        Me.wh_cd.Size = New System.Drawing.Size(195, 20)
        Me.wh_cd.TabIndex = 2
        Me.wh_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.wh_cd.Title = "wh_cd"
        Me.wh_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.wh_cd.TitleWidth = 80
        '
        'bs_cd
        '
        Me.bs_cd.Location = New System.Drawing.Point(5, 48)
        Me.bs_cd.Name = "bs_cd"
        Me.bs_cd.Size = New System.Drawing.Size(195, 20)
        Me.bs_cd.TabIndex = 2
        Me.bs_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bs_cd.Title = "bs_cd"
        Me.bs_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bs_cd.TitleWidth = 80
        '
        'co_cd
        '
        Me.co_cd.Location = New System.Drawing.Point(5, 25)
        Me.co_cd.Name = "co_cd"
        Me.co_cd.Size = New System.Drawing.Size(195, 20)
        Me.co_cd.TabIndex = 2
        Me.co_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.co_cd.Title = "co_cd"
        Me.co_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.co_cd.TitleWidth = 80
        '
        'EPanel3
        '
        Me.EPanel3.Controls.Add(Me.g10)
        Me.EPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel3.Location = New System.Drawing.Point(0, 0)
        Me.EPanel3.Name = "EPanel3"
        Me.EPanel3.Size = New System.Drawing.Size(407, 434)
        Me.EPanel3.TabIndex = 0
        Me.EPanel3.Text = "     Export List"
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(2, 22)
        Me.g10.Name = "g10"
        Me.g10.Size = New System.Drawing.Size(403, 410)
        Me.g10.TabIndex = 5
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.EPanel4)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.XtraTabControl1)
        Me.SplitContainer1.Size = New System.Drawing.Size(902, 581)
        Me.SplitContainer1.SplitterDistance = 148
        Me.SplitContainer1.TabIndex = 5
        '
        'EPanel4
        '
        Me.EPanel4.Controls.Add(Me.btn_pl)
        Me.EPanel4.Controls.Add(Me.btn_cl)
        Me.EPanel4.Controls.Add(Me.dlv_term)
        Me.EPanel4.Controls.Add(Me.pod)
        Me.EPanel4.Controls.Add(Me.pol)
        Me.EPanel4.Controls.Add(Me.dest_cd)
        Me.EPanel4.Controls.Add(Me.status)
        Me.EPanel4.Controls.Add(Me.board_dt)
        Me.EPanel4.Controls.Add(Me.ivc_dt)
        Me.EPanel4.Controls.Add(Me.cont_dt)
        Me.EPanel4.Controls.Add(Me.bl_no)
        Me.EPanel4.Controls.Add(Me.consignee)
        Me.EPanel4.Controls.Add(Me.consignee_nm)
        Me.EPanel4.Controls.Add(Me.cbm)
        Me.EPanel4.Controls.Add(Me.gross_wet)
        Me.EPanel4.Controls.Add(Me.vessel)
        Me.EPanel4.Controls.Add(Me.shipper)
        Me.EPanel4.Controls.Add(Me.shipper_nm)
        Me.EPanel4.Controls.Add(Me.ivc_no)
        Me.EPanel4.Controls.Add(Me.cont_no)
        Me.EPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel4.Location = New System.Drawing.Point(0, 0)
        Me.EPanel4.Name = "EPanel4"
        Me.EPanel4.Size = New System.Drawing.Size(902, 148)
        Me.EPanel4.TabIndex = 4
        Me.EPanel4.Text = "     Export Master"
        '
        'dlv_term
        '
        Me.dlv_term.Location = New System.Drawing.Point(614, 25)
        Me.dlv_term.Name = "dlv_term"
        Me.dlv_term.Size = New System.Drawing.Size(197, 20)
        Me.dlv_term.TabIndex = 4
        Me.dlv_term.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.dlv_term.Title = "dlv_term"
        Me.dlv_term.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.dlv_term.TitleWidth = 80
        '
        'pod
        '
        Me.pod.Location = New System.Drawing.Point(411, 94)
        Me.pod.Name = "pod"
        Me.pod.Size = New System.Drawing.Size(197, 20)
        Me.pod.TabIndex = 4
        Me.pod.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pod.Title = "pod"
        Me.pod.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pod.TitleWidth = 80
        '
        'pol
        '
        Me.pol.Location = New System.Drawing.Point(411, 71)
        Me.pol.Name = "pol"
        Me.pol.Size = New System.Drawing.Size(197, 20)
        Me.pol.TabIndex = 4
        Me.pol.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pol.Title = "pol"
        Me.pol.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pol.TitleWidth = 80
        '
        'dest_cd
        '
        Me.dest_cd.Location = New System.Drawing.Point(614, 48)
        Me.dest_cd.Name = "dest_cd"
        Me.dest_cd.Size = New System.Drawing.Size(197, 20)
        Me.dest_cd.TabIndex = 4
        Me.dest_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.dest_cd.Title = "dest_cd"
        Me.dest_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.dest_cd.TitleWidth = 80
        '
        'status
        '
        Me.status.Location = New System.Drawing.Point(208, 94)
        Me.status.Name = "status"
        Me.status.Size = New System.Drawing.Size(197, 20)
        Me.status.TabIndex = 4
        Me.status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.status.Title = "status"
        Me.status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.status.TitleWidth = 80
        '
        'board_dt
        '
        Me.board_dt.Location = New System.Drawing.Point(411, 48)
        Me.board_dt.Name = "board_dt"
        Me.board_dt.Size = New System.Drawing.Size(197, 20)
        Me.board_dt.TabIndex = 3
        Me.board_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.board_dt.Title = "board_dt"
        Me.board_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.board_dt.TitleWidth = 80
        '
        'ivc_dt
        '
        Me.ivc_dt.Location = New System.Drawing.Point(5, 94)
        Me.ivc_dt.Name = "ivc_dt"
        Me.ivc_dt.Size = New System.Drawing.Size(197, 20)
        Me.ivc_dt.TabIndex = 3
        Me.ivc_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ivc_dt.Title = "ivc_dt"
        Me.ivc_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ivc_dt.TitleWidth = 80
        '
        'cont_dt
        '
        Me.cont_dt.Location = New System.Drawing.Point(5, 48)
        Me.cont_dt.Name = "cont_dt"
        Me.cont_dt.Size = New System.Drawing.Size(197, 20)
        Me.cont_dt.TabIndex = 3
        Me.cont_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cont_dt.Title = "cont_dt"
        Me.cont_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cont_dt.TitleWidth = 80
        '
        'bl_no
        '
        Me.bl_no.Location = New System.Drawing.Point(208, 71)
        Me.bl_no.Name = "bl_no"
        Me.bl_no.Size = New System.Drawing.Size(197, 20)
        Me.bl_no.TabIndex = 2
        Me.bl_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bl_no.Title = "bl_no"
        Me.bl_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bl_no.TitleWidth = 80
        '
        'consignee
        '
        Me.consignee.Location = New System.Drawing.Point(209, 169)
        Me.consignee.Name = "consignee"
        Me.consignee.Size = New System.Drawing.Size(197, 20)
        Me.consignee.TabIndex = 2
        Me.consignee.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.consignee.Title = "consignee"
        Me.consignee.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.consignee.TitleWidth = 80
        '
        'consignee_nm
        '
        Me.consignee_nm.Location = New System.Drawing.Point(208, 48)
        Me.consignee_nm.Name = "consignee_nm"
        Me.consignee_nm.Size = New System.Drawing.Size(197, 20)
        Me.consignee_nm.TabIndex = 2
        Me.consignee_nm.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.consignee_nm.Title = "consignee_nm"
        Me.consignee_nm.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.consignee_nm.TitleWidth = 80
        '
        'cbm
        '
        Me.cbm.Location = New System.Drawing.Point(614, 94)
        Me.cbm.Name = "cbm"
        Me.cbm.Size = New System.Drawing.Size(197, 20)
        Me.cbm.TabIndex = 2
        Me.cbm.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cbm.Title = "cbm"
        Me.cbm.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cbm.TitleWidth = 80
        '
        'gross_wet
        '
        Me.gross_wet.Location = New System.Drawing.Point(614, 71)
        Me.gross_wet.Name = "gross_wet"
        Me.gross_wet.Size = New System.Drawing.Size(197, 20)
        Me.gross_wet.TabIndex = 2
        Me.gross_wet.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.gross_wet.Title = "gross_wet"
        Me.gross_wet.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.gross_wet.TitleWidth = 80
        '
        'vessel
        '
        Me.vessel.Location = New System.Drawing.Point(411, 25)
        Me.vessel.Name = "vessel"
        Me.vessel.Size = New System.Drawing.Size(197, 20)
        Me.vessel.TabIndex = 2
        Me.vessel.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vessel.Title = "vessel"
        Me.vessel.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vessel.TitleWidth = 80
        '
        'shipper
        '
        Me.shipper.Location = New System.Drawing.Point(6, 169)
        Me.shipper.Name = "shipper"
        Me.shipper.Size = New System.Drawing.Size(197, 20)
        Me.shipper.TabIndex = 2
        Me.shipper.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.shipper.Title = "shipper"
        Me.shipper.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.shipper.TitleWidth = 80
        '
        'shipper_nm
        '
        Me.shipper_nm.Location = New System.Drawing.Point(208, 25)
        Me.shipper_nm.Name = "shipper_nm"
        Me.shipper_nm.Size = New System.Drawing.Size(197, 20)
        Me.shipper_nm.TabIndex = 2
        Me.shipper_nm.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.shipper_nm.Title = "shipper_nm"
        Me.shipper_nm.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.shipper_nm.TitleWidth = 80
        '
        'ivc_no
        '
        Me.ivc_no.Location = New System.Drawing.Point(5, 71)
        Me.ivc_no.Name = "ivc_no"
        Me.ivc_no.Size = New System.Drawing.Size(197, 20)
        Me.ivc_no.TabIndex = 2
        Me.ivc_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ivc_no.Title = "ivc_no"
        Me.ivc_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ivc_no.TitleWidth = 80
        '
        'cont_no
        '
        Me.cont_no.Location = New System.Drawing.Point(5, 25)
        Me.cont_no.Name = "cont_no"
        Me.cont_no.Size = New System.Drawing.Size(197, 20)
        Me.cont_no.TabIndex = 2
        Me.cont_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cont_no.Title = "cont_no"
        Me.cont_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.cont_no.TitleWidth = 80
        '
        'btn_cl
        '
        Me.btn_cl.Location = New System.Drawing.Point(6, 117)
        Me.btn_cl.Name = "btn_cl"
        Me.btn_cl.Size = New System.Drawing.Size(95, 26)
        Me.btn_cl.TabIndex = 5
        Me.btn_cl.Text = "Print C/L"
        '
        'btn_pl
        '
        Me.btn_pl.Location = New System.Drawing.Point(107, 117)
        Me.btn_pl.Name = "btn_pl"
        Me.btn_pl.Size = New System.Drawing.Size(95, 26)
        Me.btn_pl.TabIndex = 5
        Me.btn_pl.Text = "Print P/L"
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.XtraTabPage1
        Me.XtraTabControl1.Size = New System.Drawing.Size(902, 429)
        Me.XtraTabControl1.TabIndex = 7
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage1, Me.XtraTabPage2})
        '
        'XtraTabPage1
        '
        Me.XtraTabPage1.Controls.Add(Me.g20)
        Me.XtraTabPage1.Name = "XtraTabPage1"
        Me.XtraTabPage1.Size = New System.Drawing.Size(896, 400)
        Me.XtraTabPage1.Text = "Export Detail"
        '
        'XtraTabPage2
        '
        Me.XtraTabPage2.Controls.Add(Me.g30)
        Me.XtraTabPage2.Name = "XtraTabPage2"
        Me.XtraTabPage2.Size = New System.Drawing.Size(896, 400)
        Me.XtraTabPage2.Text = "Collection"
        '
        'g30
        '
        Me.g30.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g30.Location = New System.Drawing.Point(0, 0)
        Me.g30.Name = "g30"
        Me.g30.Size = New System.Drawing.Size(896, 400)
        Me.g30.TabIndex = 7
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(0, 0)
        Me.g20.Name = "g20"
        Me.g20.Size = New System.Drawing.Size(896, 400)
        Me.g20.TabIndex = 7
        '
        'MMD600
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SplitContainer2)
        Me.Name = "MMD600"
        Me.Size = New System.Drawing.Size(1313, 581)
        Me.Controls.SetChildIndex(Me.SplitContainer2, 0)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel2.ResumeLayout(False)
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel3.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel4.ResumeLayout(False)
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.XtraTabPage1.ResumeLayout(False)
        Me.XtraTabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel2 As Frame8.ePanel
    Friend WithEvents f_pi_no As Frame8.eText
    Friend WithEvents f_ar_no As Frame8.eText
    Friend WithEvents f_buyer As Frame8.eText
    Friend WithEvents f_manu As Frame8.eText
    Friend WithEvents f_cont_no As Frame8.eText
    Friend WithEvents to_dt As Frame8.eDate
    Friend WithEvents fr_dt As Frame8.eDate
    Friend WithEvents f_status As Frame8.eCombo
    Friend WithEvents wh_cd As Frame8.eCombo
    Friend WithEvents bs_cd As Frame8.eCombo
    Friend WithEvents co_cd As Frame8.eCombo
    Friend WithEvents EPanel3 As Frame8.ePanel
    Friend WithEvents g10 As Frame8.eGrid
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel4 As Frame8.ePanel
    Friend WithEvents pod As Frame8.eCombo
    Friend WithEvents pol As Frame8.eCombo
    Friend WithEvents dest_cd As Frame8.eCombo
    Friend WithEvents status As Frame8.eCombo
    Friend WithEvents cont_dt As Frame8.eDate
    Friend WithEvents bl_no As Frame8.eText
    Friend WithEvents consignee_nm As Frame8.eText
    Friend WithEvents shipper_nm As Frame8.eText
    Friend WithEvents cont_no As Frame8.eText
    Friend WithEvents f_ivc_no As Frame8.eText
    Friend WithEvents dlv_term As Frame8.eCombo
    Friend WithEvents board_dt As Frame8.eDate
    Friend WithEvents ivc_dt As Frame8.eDate
    Friend WithEvents cbm As Frame8.eText
    Friend WithEvents gross_wet As Frame8.eText
    Friend WithEvents vessel As Frame8.eText
    Friend WithEvents ivc_no As Frame8.eText
    Friend WithEvents consignee As Frame8.eText
    Friend WithEvents shipper As Frame8.eText
    Friend WithEvents btn_pl As Frame8.eButton
    Friend WithEvents btn_cl As Frame8.eButton
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g20 As Frame8.eGrid
    Friend WithEvents g30 As Frame8.eGrid

End Class
