﻿Imports Frame8
Imports Base8
Imports Base8.Shared

Public Class MMD600
    Private Sub LEA311_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)

        Select Case mty

            Case MenuType.Save
                If Me.Save Then
                    PutMessage("SYS_SAVE", "Save Success.")
                    Me.Open()
                End If
                'Case MenuType.New
                '    req_no.Text = ""
                '    Me.OpenTrigger("LER100_g10")
                'Case MenuType.Save
                '    If Me.Save Then
                '        Me.Open()
                '    End If
                'Case MenuType.Delete
                '    Delete("LER100_f10")
            Case Else

                MyBase.MenuButton_Click(mty)

        End Select

    End Sub
End Class
