﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MMD200
    Inherits Base8.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.EPanel1 = New Frame8.ePanel()
        Me.f_status = New Frame8.eCheckCombo()
        Me.f_supplier = New Frame8.eText()
        Me.f_supplier_nm = New Frame8.eText()
        Me.f_ar_no = New Frame8.eText()
        Me.bs_cd = New Frame8.eCombo()
        Me.f_req_no = New Frame8.eText()
        Me.to_dt = New Frame8.eDate()
        Me.fr_dt = New Frame8.eDate()
        Me.f_wp_cd = New Frame8.eCombo()
        Me.co_cd = New Frame8.eCombo()
        Me.g10 = New Frame8.eGrid()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.EPanel2 = New Frame8.ePanel()
        Me.ar = New Frame8.eImage()
        Me.ar_no = New Frame8.eText()
        Me.supplier_nm = New Frame8.eText()
        Me.supplier = New Frame8.eText()
        Me.status = New Frame8.eCombo()
        Me.req_dt = New Frame8.eDate()
        Me.req_no = New Frame8.eText()
        Me.g20 = New Frame8.eGrid()
        Me.tel = New Frame8.eText()
        Me.email = New Frame8.eText()
        Me.addr = New Frame8.eText()
        Me.btn_mov_req = New Frame8.eButton()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer3)
        Me.SplitContainer1.Size = New System.Drawing.Size(1350, 750)
        Me.SplitContainer1.SplitterDistance = 423
        Me.SplitContainer1.TabIndex = 1
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.EPanel1)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.g10)
        Me.SplitContainer2.Size = New System.Drawing.Size(423, 750)
        Me.SplitContainer2.SplitterDistance = 145
        Me.SplitContainer2.TabIndex = 0
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.f_status)
        Me.EPanel1.Controls.Add(Me.f_supplier)
        Me.EPanel1.Controls.Add(Me.f_supplier_nm)
        Me.EPanel1.Controls.Add(Me.f_ar_no)
        Me.EPanel1.Controls.Add(Me.bs_cd)
        Me.EPanel1.Controls.Add(Me.f_req_no)
        Me.EPanel1.Controls.Add(Me.to_dt)
        Me.EPanel1.Controls.Add(Me.fr_dt)
        Me.EPanel1.Controls.Add(Me.f_wp_cd)
        Me.EPanel1.Controls.Add(Me.co_cd)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(423, 145)
        Me.EPanel1.TabIndex = 0
        Me.EPanel1.Text = "     Search"
        '
        'f_status
        '
        Me.f_status.Location = New System.Drawing.Point(211, 94)
        Me.f_status.Name = "f_status"
        Me.f_status.Size = New System.Drawing.Size(200, 20)
        Me.f_status.TabIndex = 25
        Me.f_status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_status.Title = "f_status"
        Me.f_status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_status.TitleWidth = 80
        '
        'f_supplier
        '
        Me.f_supplier.Location = New System.Drawing.Point(211, 117)
        Me.f_supplier.Name = "f_supplier"
        Me.f_supplier.Size = New System.Drawing.Size(200, 20)
        Me.f_supplier.TabIndex = 24
        Me.f_supplier.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_supplier.Title = "Supplier"
        Me.f_supplier.TitleAlign = Frame8.Alignment.Right
        Me.f_supplier.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_supplier.TitleWidth = 80
        '
        'f_supplier_nm
        '
        Me.f_supplier_nm.Location = New System.Drawing.Point(211, 71)
        Me.f_supplier_nm.Name = "f_supplier_nm"
        Me.f_supplier_nm.Size = New System.Drawing.Size(200, 20)
        Me.f_supplier_nm.TabIndex = 15
        Me.f_supplier_nm.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_supplier_nm.Title = "Supplier"
        Me.f_supplier_nm.TitleAlign = Frame8.Alignment.Right
        Me.f_supplier_nm.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_supplier_nm.TitleWidth = 80
        '
        'f_ar_no
        '
        Me.f_ar_no.Location = New System.Drawing.Point(211, 48)
        Me.f_ar_no.Name = "f_ar_no"
        Me.f_ar_no.Size = New System.Drawing.Size(200, 20)
        Me.f_ar_no.TabIndex = 7
        Me.f_ar_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_ar_no.Title = "AR#"
        Me.f_ar_no.TitleAlign = Frame8.Alignment.Right
        Me.f_ar_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_ar_no.TitleWidth = 80
        '
        'bs_cd
        '
        Me.bs_cd.Location = New System.Drawing.Point(5, 48)
        Me.bs_cd.Name = "bs_cd"
        Me.bs_cd.Size = New System.Drawing.Size(200, 20)
        Me.bs_cd.TabIndex = 3
        Me.bs_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bs_cd.Title = "Division"
        Me.bs_cd.TitleAlign = Frame8.Alignment.Right
        Me.bs_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bs_cd.TitleWidth = 80
        '
        'f_req_no
        '
        Me.f_req_no.Location = New System.Drawing.Point(211, 25)
        Me.f_req_no.Name = "f_req_no"
        Me.f_req_no.Size = New System.Drawing.Size(200, 20)
        Me.f_req_no.TabIndex = 7
        Me.f_req_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_req_no.Title = "Req#"
        Me.f_req_no.TitleAlign = Frame8.Alignment.Right
        Me.f_req_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_req_no.TitleWidth = 80
        '
        'to_dt
        '
        Me.to_dt.Location = New System.Drawing.Point(5, 117)
        Me.to_dt.Name = "to_dt"
        Me.to_dt.Size = New System.Drawing.Size(200, 20)
        Me.to_dt.TabIndex = 15
        Me.to_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.to_dt.Title = "Req Date"
        Me.to_dt.TitleAlign = Frame8.Alignment.Right
        Me.to_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.to_dt.TitleWidth = 80
        '
        'fr_dt
        '
        Me.fr_dt.Location = New System.Drawing.Point(5, 94)
        Me.fr_dt.Name = "fr_dt"
        Me.fr_dt.Size = New System.Drawing.Size(200, 20)
        Me.fr_dt.TabIndex = 15
        Me.fr_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.fr_dt.Title = "Req Date"
        Me.fr_dt.TitleAlign = Frame8.Alignment.Right
        Me.fr_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.fr_dt.TitleWidth = 80
        '
        'f_wp_cd
        '
        Me.f_wp_cd.Location = New System.Drawing.Point(5, 71)
        Me.f_wp_cd.Name = "f_wp_cd"
        Me.f_wp_cd.Size = New System.Drawing.Size(200, 20)
        Me.f_wp_cd.TabIndex = 5
        Me.f_wp_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_wp_cd.Title = "WorkPlace"
        Me.f_wp_cd.TitleAlign = Frame8.Alignment.Right
        Me.f_wp_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_wp_cd.TitleWidth = 80
        '
        'co_cd
        '
        Me.co_cd.Location = New System.Drawing.Point(5, 25)
        Me.co_cd.Name = "co_cd"
        Me.co_cd.Size = New System.Drawing.Size(200, 20)
        Me.co_cd.TabIndex = 2
        Me.co_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.co_cd.Title = "Company"
        Me.co_cd.TitleAlign = Frame8.Alignment.Right
        Me.co_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.co_cd.TitleWidth = 80
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(0, 0)
        Me.g10.Name = "g10"
        Me.g10.Size = New System.Drawing.Size(423, 601)
        Me.g10.TabIndex = 0
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.EPanel2)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.g20)
        Me.SplitContainer3.Size = New System.Drawing.Size(923, 750)
        Me.SplitContainer3.SplitterDistance = 99
        Me.SplitContainer3.TabIndex = 0
        '
        'EPanel2
        '
        Me.EPanel2.Controls.Add(Me.btn_mov_req)
        Me.EPanel2.Controls.Add(Me.ar)
        Me.EPanel2.Controls.Add(Me.ar_no)
        Me.EPanel2.Controls.Add(Me.supplier_nm)
        Me.EPanel2.Controls.Add(Me.email)
        Me.EPanel2.Controls.Add(Me.addr)
        Me.EPanel2.Controls.Add(Me.tel)
        Me.EPanel2.Controls.Add(Me.supplier)
        Me.EPanel2.Controls.Add(Me.status)
        Me.EPanel2.Controls.Add(Me.req_dt)
        Me.EPanel2.Controls.Add(Me.req_no)
        Me.EPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel2.Location = New System.Drawing.Point(0, 0)
        Me.EPanel2.Name = "EPanel2"
        Me.EPanel2.Size = New System.Drawing.Size(923, 99)
        Me.EPanel2.TabIndex = 1
        Me.EPanel2.Text = "     Registration"
        '
        'ar
        '
        Me.ar.Location = New System.Drawing.Point(833, 25)
        Me.ar.Name = "ar"
        Me.ar.Size = New System.Drawing.Size(85, 66)
        Me.ar.TabIndex = 23
        Me.ar.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        '
        'ar_no
        '
        Me.ar_no.Location = New System.Drawing.Point(627, 25)
        Me.ar_no.Name = "ar_no"
        Me.ar_no.Size = New System.Drawing.Size(200, 20)
        Me.ar_no.TabIndex = 22
        Me.ar_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ar_no.Title = "AR#"
        Me.ar_no.TitleAlign = Frame8.Alignment.Right
        Me.ar_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.ar_no.TitleWidth = 80
        '
        'supplier_nm
        '
        Me.supplier_nm.Location = New System.Drawing.Point(419, 25)
        Me.supplier_nm.Name = "supplier_nm"
        Me.supplier_nm.Size = New System.Drawing.Size(202, 20)
        Me.supplier_nm.TabIndex = 20
        Me.supplier_nm.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.supplier_nm.Title = "Name"
        Me.supplier_nm.TitleAlign = Frame8.Alignment.Right
        Me.supplier_nm.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.supplier_nm.TitleWidth = 80
        '
        'supplier
        '
        Me.supplier.Location = New System.Drawing.Point(211, 25)
        Me.supplier.Name = "supplier"
        Me.supplier.Size = New System.Drawing.Size(202, 20)
        Me.supplier.TabIndex = 19
        Me.supplier.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.supplier.Title = "Supplier"
        Me.supplier.TitleAlign = Frame8.Alignment.Right
        Me.supplier.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.supplier.TitleWidth = 80
        '
        'status
        '
        Me.status.Location = New System.Drawing.Point(627, 48)
        Me.status.Name = "status"
        Me.status.Size = New System.Drawing.Size(200, 20)
        Me.status.TabIndex = 9
        Me.status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.status.Title = "status"
        Me.status.TitleAlign = Frame8.Alignment.Right
        Me.status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.status.TitleWidth = 80
        '
        'req_dt
        '
        Me.req_dt.Location = New System.Drawing.Point(5, 48)
        Me.req_dt.Name = "req_dt"
        Me.req_dt.Size = New System.Drawing.Size(200, 20)
        Me.req_dt.TabIndex = 5
        Me.req_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.req_dt.Title = "Req Date"
        Me.req_dt.TitleAlign = Frame8.Alignment.Right
        Me.req_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.req_dt.TitleWidth = 80
        '
        'req_no
        '
        Me.req_no.Location = New System.Drawing.Point(5, 25)
        Me.req_no.Name = "req_no"
        Me.req_no.Size = New System.Drawing.Size(200, 20)
        Me.req_no.TabIndex = 6
        Me.req_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.req_no.Title = "Req#"
        Me.req_no.TitleAlign = Frame8.Alignment.Right
        Me.req_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.req_no.TitleWidth = 80
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(0, 0)
        Me.g20.Name = "g20"
        Me.g20.Size = New System.Drawing.Size(923, 647)
        Me.g20.TabIndex = 1
        '
        'tel
        '
        Me.tel.Location = New System.Drawing.Point(211, 48)
        Me.tel.Name = "tel"
        Me.tel.Size = New System.Drawing.Size(202, 20)
        Me.tel.TabIndex = 19
        Me.tel.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.tel.Title = "tel"
        Me.tel.TitleAlign = Frame8.Alignment.Right
        Me.tel.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.tel.TitleWidth = 80
        '
        'email
        '
        Me.email.Location = New System.Drawing.Point(419, 48)
        Me.email.Name = "email"
        Me.email.Size = New System.Drawing.Size(202, 20)
        Me.email.TabIndex = 19
        Me.email.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.email.Title = "email"
        Me.email.TitleAlign = Frame8.Alignment.Right
        Me.email.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.email.TitleWidth = 80
        '
        'addr
        '
        Me.addr.Location = New System.Drawing.Point(213, 71)
        Me.addr.Name = "addr"
        Me.addr.Size = New System.Drawing.Size(408, 20)
        Me.addr.TabIndex = 19
        Me.addr.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.addr.Title = "addr"
        Me.addr.TitleAlign = Frame8.Alignment.Right
        Me.addr.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.addr.TitleWidth = 80
        '
        'btn_mov_req
        '
        Me.btn_mov_req.Location = New System.Drawing.Point(101, 71)
        Me.btn_mov_req.Name = "btn_mov_req"
        Me.btn_mov_req.Size = New System.Drawing.Size(104, 23)
        Me.btn_mov_req.TabIndex = 26
        Me.btn_mov_req.Text = "Moving Req."
        '
        'MMD200
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "MMD200"
        Me.Size = New System.Drawing.Size(1350, 750)
        Me.Controls.SetChildIndex(Me.SplitContainer1, 0)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel1 As Frame8.ePanel
    Friend WithEvents f_supplier_nm As Frame8.eText
    Friend WithEvents f_ar_no As Frame8.eText
    Friend WithEvents req_no As Frame8.eText
    Friend WithEvents req_dt As Frame8.eDate
    Friend WithEvents bs_cd As Frame8.eCombo
    Friend WithEvents co_cd As Frame8.eCombo
    Friend WithEvents g10 As Frame8.eGrid
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel2 As Frame8.ePanel
    Friend WithEvents ar_no As Frame8.eText
    Friend WithEvents supplier_nm As Frame8.eText
    Friend WithEvents supplier As Frame8.eText
    Friend WithEvents fr_dt As Frame8.eDate
    Friend WithEvents f_req_no As Frame8.eText
    Friend WithEvents f_wp_cd As Frame8.eCombo
    Friend WithEvents g20 As Frame8.eGrid
    Friend WithEvents to_dt As Frame8.eDate
    Friend WithEvents f_supplier As Frame8.eText
    Friend WithEvents ar As Frame8.eImage
    Friend WithEvents status As Frame8.eCombo
    Friend WithEvents f_status As Frame8.eCheckCombo
    Friend WithEvents email As Frame8.eText
    Friend WithEvents addr As Frame8.eText
    Friend WithEvents tel As Frame8.eText
    Friend WithEvents btn_mov_req As Frame8.eButton

End Class
