﻿Imports Frame8
Imports Base8
Imports Base8.Shared 

Public Class MMD200


    '######################################################################################
    '##             Form Event                                                           ##
    '######################################################################################

    Private Sub Form_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        req_no.CodeNo = "MMD200"
        req_no.CodeDateField = req_dt
    End Sub

    Public Sub Init_Form()

    End Sub

    '######################################################################################
    '##             ToolBar Function                                                     ##
    '######################################################################################

    Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)

        Select Case mty

            Case MenuType.New
                req_no.Text = ""
                OpenTrigger("MMD200_g10")

                'Case MenuType.Save

                'Case MenuType.Delete

            Case Else

                MyBase.MenuButton_Click(mty)

        End Select

    End Sub

    '######################################################################################
    '##            Open                                                                  ##
    '######################################################################################

    Private Sub New_Form()
        Try
        Catch ex As Exception
            MessageError(ex)
        End Try
    End Sub

    Private Sub Open_Form()
        Try

        Catch ex As Exception
            MessageError(ex)
        End Try
    End Sub

    '######################################################################################
    '##            Save                                                                  ##
    '######################################################################################

    'Private Function Save_Form() As Boolean

    '    '        Dim ID As String = asset_id.Text
    '    Try

    '        '            If MyBase.Save() Then
    '        '                If ID = "" Then
    '        '                    f_asset_id.Text = asset_id.Text
    '        '                    Me.Open()
    '        '                Else
    '        '                    Form_Open()
    '        '                End If
    '        '            Else
    '        '                If ID = "" Then asset_id.Text = ""
    '        '            End If

    '    Catch ex As Exception
    '        '            If ID = "" Then asset_id.Text = ""
    '        '저장에 실패했으면 코드 채번을 반드시 취소한다
    '        MessageError(ex)
    '    End Try
    'End Function

End Class
