﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MMD300
    Inherits Base8.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.g00 = New Frame8.eGrid()
        Me.EPanel1 = New Frame8.ePanel()
        Me.f_supplier = New Frame8.eText()
        Me.f_bl_container = New Frame8.eText()
        Me.f_bl_no = New Frame8.eText()
        Me.f_lc_no = New Frame8.eText()
        Me.f_po_no = New Frame8.eText()
        Me.f_status = New Frame8.eCombo()
        Me.f_category = New Frame8.eCombo()
        Me.f_po_dest = New Frame8.eCombo()
        Me.f_lc_dt_fr = New Frame8.eDate()
        Me.f_lc_dt_to = New Frame8.eDate()
        Me.co_cd = New Frame8.eCombo()
        Me.bs_cd = New Frame8.eCombo()
        Me.SplitContainer5 = New System.Windows.Forms.SplitContainer()
        Me.EPanel2 = New Frame8.ePanel()
        Me.btn_copy = New Frame8.eButton()
        Me.status = New Frame8.eCombo()
        Me.supplier = New Frame8.eText()
        Me.lc_no = New Frame8.eText()
        Me.pi_no = New Frame8.eText()
        Me.po_no = New Frame8.eText()
        Me.vs_packcount = New Frame8.eCombo()
        Me.vs_packstyle = New Frame8.eCombo()
        Me.vs_capacity = New Frame8.eCombo()
        Me.vs_ton = New Frame8.eCombo()
        Me.vs_origin = New Frame8.eCombo()
        Me.bl_dest = New Frame8.eCombo()
        Me.bl_serial = New Frame8.eText()
        Me.eta = New Frame8.eDate()
        Me.f_supplier_cd = New Frame8.eText()
        Me.bl_rmks = New Frame8.eMemo()
        Me.port_loading = New Frame8.eCombo()
        Me.etd = New Frame8.eDate()
        Me.vs_name = New Frame8.eText()
        Me.bl_dt = New Frame8.eDate()
        Me.bl_no = New Frame8.eText()
        Me.g20 = New Frame8.eGrid()
        Me.g10 = New Frame8.eGrid()
        Me.ETreeGrid1 = New Frame8.eTreeGrid()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        Me.SplitContainer5.Panel1.SuspendLayout()
        Me.SplitContainer5.Panel2.SuspendLayout()
        Me.SplitContainer5.SuspendLayout()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.g00)
        Me.SplitContainer1.Panel1.Controls.Add(Me.EPanel1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer5)
        Me.SplitContainer1.Size = New System.Drawing.Size(1350, 628)
        Me.SplitContainer1.SplitterDistance = 434
        Me.SplitContainer1.TabIndex = 0
        '
        'g00
        '
        Me.g00.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g00.Location = New System.Drawing.Point(0, 175)
        Me.g00.Name = "g00"
        Me.g00.Size = New System.Drawing.Size(434, 453)
        Me.g00.TabIndex = 5
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.f_supplier)
        Me.EPanel1.Controls.Add(Me.f_bl_container)
        Me.EPanel1.Controls.Add(Me.f_bl_no)
        Me.EPanel1.Controls.Add(Me.f_lc_no)
        Me.EPanel1.Controls.Add(Me.f_po_no)
        Me.EPanel1.Controls.Add(Me.f_status)
        Me.EPanel1.Controls.Add(Me.f_category)
        Me.EPanel1.Controls.Add(Me.f_po_dest)
        Me.EPanel1.Controls.Add(Me.f_lc_dt_fr)
        Me.EPanel1.Controls.Add(Me.f_lc_dt_to)
        Me.EPanel1.Controls.Add(Me.co_cd)
        Me.EPanel1.Controls.Add(Me.bs_cd)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(434, 175)
        Me.EPanel1.TabIndex = 0
        Me.EPanel1.Text = "     검색조건"
        '
        'f_supplier
        '
        Me.f_supplier.Location = New System.Drawing.Point(12, 98)
        Me.f_supplier.Name = "f_supplier"
        Me.f_supplier.Size = New System.Drawing.Size(205, 20)
        Me.f_supplier.TabIndex = 217
        Me.f_supplier.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_supplier.Title = "f_supplier"
        Me.f_supplier.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_supplier.TitleWidth = 90
        '
        'f_bl_container
        '
        Me.f_bl_container.Location = New System.Drawing.Point(223, 146)
        Me.f_bl_container.Name = "f_bl_container"
        Me.f_bl_container.Size = New System.Drawing.Size(205, 20)
        Me.f_bl_container.TabIndex = 216
        Me.f_bl_container.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_bl_container.Title = "f_bl_container"
        Me.f_bl_container.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_bl_container.TitleWidth = 90
        '
        'f_bl_no
        '
        Me.f_bl_no.Location = New System.Drawing.Point(223, 122)
        Me.f_bl_no.Name = "f_bl_no"
        Me.f_bl_no.Size = New System.Drawing.Size(205, 20)
        Me.f_bl_no.TabIndex = 215
        Me.f_bl_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_bl_no.Title = "f_bl_no"
        Me.f_bl_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_bl_no.TitleWidth = 90
        '
        'f_lc_no
        '
        Me.f_lc_no.Location = New System.Drawing.Point(223, 98)
        Me.f_lc_no.Name = "f_lc_no"
        Me.f_lc_no.Size = New System.Drawing.Size(205, 20)
        Me.f_lc_no.TabIndex = 214
        Me.f_lc_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_lc_no.Title = "f_lc_no"
        Me.f_lc_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_lc_no.TitleWidth = 90
        '
        'f_po_no
        '
        Me.f_po_no.Location = New System.Drawing.Point(223, 75)
        Me.f_po_no.Name = "f_po_no"
        Me.f_po_no.Size = New System.Drawing.Size(205, 20)
        Me.f_po_no.TabIndex = 213
        Me.f_po_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_po_no.Title = "f_po_no"
        Me.f_po_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_po_no.TitleWidth = 90
        '
        'f_status
        '
        Me.f_status.Location = New System.Drawing.Point(12, 146)
        Me.f_status.Name = "f_status"
        Me.f_status.Size = New System.Drawing.Size(205, 20)
        Me.f_status.TabIndex = 211
        Me.f_status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_status.Title = "f_status"
        Me.f_status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_status.TitleWidth = 90
        '
        'f_category
        '
        Me.f_category.Location = New System.Drawing.Point(12, 75)
        Me.f_category.Name = "f_category"
        Me.f_category.Size = New System.Drawing.Size(205, 20)
        Me.f_category.TabIndex = 206
        Me.f_category.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_category.Title = "f_category"
        Me.f_category.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_category.TitleWidth = 90
        '
        'f_po_dest
        '
        Me.f_po_dest.Location = New System.Drawing.Point(12, 122)
        Me.f_po_dest.Name = "f_po_dest"
        Me.f_po_dest.Size = New System.Drawing.Size(205, 20)
        Me.f_po_dest.TabIndex = 204
        Me.f_po_dest.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_po_dest.Title = "f_po_dest"
        Me.f_po_dest.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_po_dest.TitleWidth = 90
        '
        'f_lc_dt_fr
        '
        Me.f_lc_dt_fr.Location = New System.Drawing.Point(223, 28)
        Me.f_lc_dt_fr.Name = "f_lc_dt_fr"
        Me.f_lc_dt_fr.Size = New System.Drawing.Size(205, 20)
        Me.f_lc_dt_fr.TabIndex = 203
        Me.f_lc_dt_fr.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_lc_dt_fr.Title = "f_lc_dt_fr"
        Me.f_lc_dt_fr.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_lc_dt_fr.TitleWidth = 90
        '
        'f_lc_dt_to
        '
        Me.f_lc_dt_to.Location = New System.Drawing.Point(223, 52)
        Me.f_lc_dt_to.Name = "f_lc_dt_to"
        Me.f_lc_dt_to.Size = New System.Drawing.Size(205, 20)
        Me.f_lc_dt_to.TabIndex = 202
        Me.f_lc_dt_to.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_lc_dt_to.Title = "f_lc_dt_to"
        Me.f_lc_dt_to.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_lc_dt_to.TitleWidth = 90
        '
        'co_cd
        '
        Me.co_cd.Location = New System.Drawing.Point(12, 28)
        Me.co_cd.Name = "co_cd"
        Me.co_cd.Size = New System.Drawing.Size(205, 20)
        Me.co_cd.TabIndex = 5
        Me.co_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.co_cd.Title = "co_cd"
        Me.co_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.co_cd.TitleWidth = 90
        '
        'bs_cd
        '
        Me.bs_cd.Location = New System.Drawing.Point(12, 52)
        Me.bs_cd.Name = "bs_cd"
        Me.bs_cd.Size = New System.Drawing.Size(205, 20)
        Me.bs_cd.TabIndex = 7
        Me.bs_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bs_cd.Title = "bs_cd"
        Me.bs_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bs_cd.TitleWidth = 90
        '
        'SplitContainer5
        '
        Me.SplitContainer5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer5.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer5.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer5.Name = "SplitContainer5"
        Me.SplitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer5.Panel1
        '
        Me.SplitContainer5.Panel1.Controls.Add(Me.EPanel2)
        '
        'SplitContainer5.Panel2
        '
        Me.SplitContainer5.Panel2.Controls.Add(Me.g20)
        Me.SplitContainer5.Panel2.Controls.Add(Me.g10)
        Me.SplitContainer5.Panel2.Controls.Add(Me.ETreeGrid1)
        Me.SplitContainer5.Size = New System.Drawing.Size(912, 628)
        Me.SplitContainer5.SplitterDistance = 174
        Me.SplitContainer5.TabIndex = 1
        '
        'EPanel2
        '
        Me.EPanel2.Controls.Add(Me.btn_copy)
        Me.EPanel2.Controls.Add(Me.status)
        Me.EPanel2.Controls.Add(Me.supplier)
        Me.EPanel2.Controls.Add(Me.lc_no)
        Me.EPanel2.Controls.Add(Me.pi_no)
        Me.EPanel2.Controls.Add(Me.po_no)
        Me.EPanel2.Controls.Add(Me.vs_packcount)
        Me.EPanel2.Controls.Add(Me.vs_packstyle)
        Me.EPanel2.Controls.Add(Me.vs_capacity)
        Me.EPanel2.Controls.Add(Me.vs_ton)
        Me.EPanel2.Controls.Add(Me.vs_origin)
        Me.EPanel2.Controls.Add(Me.bl_dest)
        Me.EPanel2.Controls.Add(Me.bl_serial)
        Me.EPanel2.Controls.Add(Me.eta)
        Me.EPanel2.Controls.Add(Me.f_supplier_cd)
        Me.EPanel2.Controls.Add(Me.bl_rmks)
        Me.EPanel2.Controls.Add(Me.port_loading)
        Me.EPanel2.Controls.Add(Me.etd)
        Me.EPanel2.Controls.Add(Me.vs_name)
        Me.EPanel2.Controls.Add(Me.bl_dt)
        Me.EPanel2.Controls.Add(Me.bl_no)
        Me.EPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel2.Location = New System.Drawing.Point(0, 0)
        Me.EPanel2.Name = "EPanel2"
        Me.EPanel2.Size = New System.Drawing.Size(912, 174)
        Me.EPanel2.TabIndex = 0
        Me.EPanel2.Text = "     BL"
        '
        'btn_copy
        '
        Me.btn_copy.Location = New System.Drawing.Point(608, 111)
        Me.btn_copy.Name = "btn_copy"
        Me.btn_copy.Size = New System.Drawing.Size(85, 33)
        Me.btn_copy.TabIndex = 302
        Me.btn_copy.Text = "Row Copy"
        '
        'status
        '
        Me.status.Location = New System.Drawing.Point(5, 124)
        Me.status.Name = "status"
        Me.status.Size = New System.Drawing.Size(195, 20)
        Me.status.TabIndex = 301
        Me.status.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.status.Title = "status"
        Me.status.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.status.TitleWidth = 80
        '
        'supplier
        '
        Me.supplier.Location = New System.Drawing.Point(206, 124)
        Me.supplier.Name = "supplier"
        Me.supplier.Size = New System.Drawing.Size(195, 20)
        Me.supplier.TabIndex = 298
        Me.supplier.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.supplier.Title = "supplier"
        Me.supplier.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.supplier.TitleWidth = 80
        '
        'lc_no
        '
        Me.lc_no.Location = New System.Drawing.Point(608, 76)
        Me.lc_no.Name = "lc_no"
        Me.lc_no.Size = New System.Drawing.Size(195, 20)
        Me.lc_no.TabIndex = 297
        Me.lc_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.lc_no.Title = "lc_no"
        Me.lc_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.lc_no.TitleWidth = 80
        '
        'pi_no
        '
        Me.pi_no.Location = New System.Drawing.Point(608, 52)
        Me.pi_no.Name = "pi_no"
        Me.pi_no.Size = New System.Drawing.Size(195, 20)
        Me.pi_no.TabIndex = 296
        Me.pi_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pi_no.Title = "pi_no"
        Me.pi_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.pi_no.TitleWidth = 80
        '
        'po_no
        '
        Me.po_no.Location = New System.Drawing.Point(608, 28)
        Me.po_no.Name = "po_no"
        Me.po_no.Size = New System.Drawing.Size(195, 20)
        Me.po_no.TabIndex = 295
        Me.po_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.po_no.Title = "po_no"
        Me.po_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.po_no.TitleWidth = 80
        '
        'vs_packcount
        '
        Me.vs_packcount.Location = New System.Drawing.Point(407, 124)
        Me.vs_packcount.Name = "vs_packcount"
        Me.vs_packcount.Size = New System.Drawing.Size(195, 20)
        Me.vs_packcount.TabIndex = 288
        Me.vs_packcount.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_packcount.Title = "vs_packcount"
        Me.vs_packcount.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_packcount.TitleWidth = 80
        '
        'vs_packstyle
        '
        Me.vs_packstyle.Location = New System.Drawing.Point(407, 100)
        Me.vs_packstyle.Name = "vs_packstyle"
        Me.vs_packstyle.Size = New System.Drawing.Size(195, 20)
        Me.vs_packstyle.TabIndex = 287
        Me.vs_packstyle.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_packstyle.Title = "vs_packstyle"
        Me.vs_packstyle.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_packstyle.TitleWidth = 80
        '
        'vs_capacity
        '
        Me.vs_capacity.Location = New System.Drawing.Point(407, 76)
        Me.vs_capacity.Name = "vs_capacity"
        Me.vs_capacity.Size = New System.Drawing.Size(195, 20)
        Me.vs_capacity.TabIndex = 286
        Me.vs_capacity.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_capacity.Title = "vs_capacity"
        Me.vs_capacity.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_capacity.TitleWidth = 80
        '
        'vs_ton
        '
        Me.vs_ton.Location = New System.Drawing.Point(407, 52)
        Me.vs_ton.Name = "vs_ton"
        Me.vs_ton.Size = New System.Drawing.Size(195, 20)
        Me.vs_ton.TabIndex = 285
        Me.vs_ton.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_ton.Title = "vs_ton"
        Me.vs_ton.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_ton.TitleWidth = 80
        '
        'vs_origin
        '
        Me.vs_origin.Location = New System.Drawing.Point(407, 28)
        Me.vs_origin.Name = "vs_origin"
        Me.vs_origin.Size = New System.Drawing.Size(195, 20)
        Me.vs_origin.TabIndex = 284
        Me.vs_origin.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_origin.Title = "vs_origin"
        Me.vs_origin.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_origin.TitleWidth = 80
        '
        'bl_dest
        '
        Me.bl_dest.Location = New System.Drawing.Point(206, 76)
        Me.bl_dest.Name = "bl_dest"
        Me.bl_dest.Size = New System.Drawing.Size(195, 20)
        Me.bl_dest.TabIndex = 283
        Me.bl_dest.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bl_dest.Title = "bl_dest"
        Me.bl_dest.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bl_dest.TitleWidth = 80
        '
        'bl_serial
        '
        Me.bl_serial.Location = New System.Drawing.Point(206, 28)
        Me.bl_serial.Name = "bl_serial"
        Me.bl_serial.Size = New System.Drawing.Size(195, 20)
        Me.bl_serial.TabIndex = 282
        Me.bl_serial.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bl_serial.Title = "bl_serial"
        Me.bl_serial.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bl_serial.TitleWidth = 80
        '
        'eta
        '
        Me.eta.Location = New System.Drawing.Point(5, 100)
        Me.eta.Name = "eta"
        Me.eta.Size = New System.Drawing.Size(195, 20)
        Me.eta.TabIndex = 281
        Me.eta.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.eta.Title = "eta"
        Me.eta.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.eta.TitleWidth = 80
        '
        'f_supplier_cd
        '
        Me.f_supplier_cd.Location = New System.Drawing.Point(809, 28)
        Me.f_supplier_cd.Name = "f_supplier_cd"
        Me.f_supplier_cd.Size = New System.Drawing.Size(100, 20)
        Me.f_supplier_cd.TabIndex = 279
        Me.f_supplier_cd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_supplier_cd.Title = "f_supplier_cd"
        Me.f_supplier_cd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.f_supplier_cd.TitleWidth = 50
        '
        'bl_rmks
        '
        Me.bl_rmks.Location = New System.Drawing.Point(5, 147)
        Me.bl_rmks.Name = "bl_rmks"
        Me.bl_rmks.Size = New System.Drawing.Size(798, 20)
        Me.bl_rmks.TabIndex = 269
        Me.bl_rmks.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bl_rmks.Title = "lc_rmks"
        Me.bl_rmks.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bl_rmks.TitleWidth = 80
        '
        'port_loading
        '
        Me.port_loading.Location = New System.Drawing.Point(206, 52)
        Me.port_loading.Name = "port_loading"
        Me.port_loading.Size = New System.Drawing.Size(195, 20)
        Me.port_loading.TabIndex = 252
        Me.port_loading.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.port_loading.Title = "port_loading"
        Me.port_loading.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.port_loading.TitleWidth = 80
        '
        'etd
        '
        Me.etd.Location = New System.Drawing.Point(5, 76)
        Me.etd.Name = "etd"
        Me.etd.Size = New System.Drawing.Size(195, 20)
        Me.etd.TabIndex = 250
        Me.etd.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.etd.Title = "etd"
        Me.etd.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.etd.TitleWidth = 80
        '
        'vs_name
        '
        Me.vs_name.Location = New System.Drawing.Point(206, 100)
        Me.vs_name.Name = "vs_name"
        Me.vs_name.Size = New System.Drawing.Size(195, 20)
        Me.vs_name.TabIndex = 248
        Me.vs_name.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_name.Title = "vs_name"
        Me.vs_name.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.vs_name.TitleWidth = 80
        '
        'bl_dt
        '
        Me.bl_dt.Location = New System.Drawing.Point(5, 52)
        Me.bl_dt.Name = "bl_dt"
        Me.bl_dt.Size = New System.Drawing.Size(195, 20)
        Me.bl_dt.TabIndex = 247
        Me.bl_dt.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bl_dt.Title = "bl_dt"
        Me.bl_dt.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bl_dt.TitleWidth = 80
        '
        'bl_no
        '
        Me.bl_no.Location = New System.Drawing.Point(5, 28)
        Me.bl_no.Name = "bl_no"
        Me.bl_no.Size = New System.Drawing.Size(195, 20)
        Me.bl_no.TabIndex = 246
        Me.bl_no.TextForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bl_no.Title = "bl_no"
        Me.bl_no.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.bl_no.TitleWidth = 80
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(0, 0)
        Me.g20.Name = "g20"
        Me.g20.Size = New System.Drawing.Size(912, 450)
        Me.g20.TabIndex = 2
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(0, 0)
        Me.g10.Name = "g10"
        Me.g10.Size = New System.Drawing.Size(912, 450)
        Me.g10.TabIndex = 1
        '
        'ETreeGrid1
        '
        Me.ETreeGrid1.Location = New System.Drawing.Point(486, 404)
        Me.ETreeGrid1.Name = "ETreeGrid1"
        Me.ETreeGrid1.Size = New System.Drawing.Size(492, 318)
        Me.ETreeGrid1.StateImageList = Nothing
        Me.ETreeGrid1.TabIndex = 0
        '
        'MMD300
        '
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "MMD300"
        Me.Size = New System.Drawing.Size(1350, 628)
        Me.Controls.SetChildIndex(Me.SplitContainer1, 0)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        Me.SplitContainer5.Panel1.ResumeLayout(False)
        Me.SplitContainer5.Panel2.ResumeLayout(False)
        Me.SplitContainer5.ResumeLayout(False)
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel1 As Frame8.ePanel
    Friend WithEvents SplitContainer5 As System.Windows.Forms.SplitContainer
    Friend WithEvents bs_cd As Frame8.eCombo
    Friend WithEvents co_cd As Frame8.eCombo
    Friend WithEvents f_lc_dt_fr As Frame8.eDate
    Friend WithEvents f_lc_dt_to As Frame8.eDate
    Friend WithEvents f_po_dest As Frame8.eCombo
    Friend WithEvents f_status As Frame8.eCombo
    Friend WithEvents f_category As Frame8.eCombo
    Friend WithEvents g10 As Frame8.eGrid
    Friend WithEvents ETreeGrid1 As Frame8.eTreeGrid
    Friend WithEvents g20 As Frame8.eGrid
    Friend WithEvents f_bl_container As Frame8.eText
    Friend WithEvents f_bl_no As Frame8.eText
    Friend WithEvents f_lc_no As Frame8.eText
    Friend WithEvents f_po_no As Frame8.eText
    Friend WithEvents EPanel2 As Frame8.ePanel
    Friend WithEvents port_loading As Frame8.eCombo
    Friend WithEvents etd As Frame8.eDate
    Friend WithEvents vs_name As Frame8.eText
    Friend WithEvents bl_dt As Frame8.eDate
    Friend WithEvents bl_no As Frame8.eText
    Friend WithEvents f_supplier_cd As Frame8.eText
    Friend WithEvents g00 As Frame8.eGrid
    Friend WithEvents f_supplier As Frame8.eText
    Friend WithEvents bl_rmks As Frame8.eMemo
    Friend WithEvents eta As Frame8.eDate
    Friend WithEvents bl_serial As Frame8.eText
    Friend WithEvents bl_dest As Frame8.eCombo
    Friend WithEvents vs_packcount As Frame8.eCombo
    Friend WithEvents vs_packstyle As Frame8.eCombo
    Friend WithEvents vs_capacity As Frame8.eCombo
    Friend WithEvents vs_ton As Frame8.eCombo
    Friend WithEvents vs_origin As Frame8.eCombo
    Friend WithEvents pi_no As Frame8.eText
    Friend WithEvents po_no As Frame8.eText
    Friend WithEvents supplier As Frame8.eText
    Friend WithEvents lc_no As Frame8.eText
    Friend WithEvents status As Frame8.eCombo
    Friend WithEvents btn_copy As Frame8.eButton

End Class
