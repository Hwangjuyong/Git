﻿Imports Frame8
Imports Base8
Imports Base8.Shared
Imports System.Data

Public Class MMD300
    Private Sub MMB300_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        '구매의뢰번호 자동채번 설정
        bl_no.CodeNo = "MMD300"        'Function dbo.[fnCodeNo]안에 LEB100에 대한 코딩을 해야 한다
        bl_no.CodeDateField = bl_dt

        If f_category.Text <> "DM000100" Then
            g10.Visible = False
            g20.Visible = True
        Else
            g10.Visible = True
            g20.Visible = False
        End If
        Me.NewForm()

    End Sub
    Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)

        Select Case mty

            Case MenuType.New
                bl_no.Text = ""
                OpenTrigger("mmd300_g00")
                f_supplier_cd.Text = g00.Text("supplier_cd")
                supplier.Text = g00.Text("supplier")
                lc_no.Text = g00.Text("lc_no")
                pi_no.Text = g00.Text("pi_no")
                po_no.Text = g00.Text("po_no")

            Case MenuType.Save
                'If cl_3dt.Text <> "" Then
                '    If cl_2dt.Text > cl_3dt.Text Or cl_2dt.Text = "" Then
                '        PutMessage("mmd300_02", "Date 3rd is wrong")
                '        Return
                '    End If
                'End If

                'If cl_2dt.Text <> "" Then
                '    If cl_1dt.Text > cl_2dt.Text Or cl_1dt.Text = "" Then
                '        PutMessage("mmd300_03", "Date 2rd is wrong")
                '        Return
                '    End If
                'End If

                'If cl_1dt.Text <> "" Then
                '    If bl_dt.Text > cl_1dt.Text Then
                '        PutMessage("mmd300_04", "Date 1rd is wrong")
                '        Return
                '    End If
                'End If

                If g00.Text("lc_dt") > bl_dt.Text Then
                    PutMessage("mmd300_05", "BL Date is wrong")
                    Return
                End If
                If bl_dt.Text > etd.Text Then
                    PutMessage("mmd300_06", "ETD is wrong")
                    Return
                End If
                If etd.Text > eta.Text Then
                    PutMessage("mmd300_07", "ETA is wrong")
                    Return
                End If

                For i As Integer = 0 To g10.RowCount - 1
                    If (g10.Text("bl_container", i) = "" Or g10.ToDec("qty") = 0) And f_category.Text = "DM000100" Then
                        PutMessage("mmd300_08", "[Container], [Qty] is Required")
                        Exit Sub
                    End If
                    If (g20.Text("bl_container", i) = "" Or g20.ToDec("qty", i) = 0) And f_category.Text <> "DM000100" Then
                        PutMessage("mmd300_08", "[Container], [Qty] is Required")
                        Exit Sub
                    End If
                Next

                If Me.Save Then
                    PutMessage("SYS_SAVE", "Save Success.")
                    Dim finder As String = bl_no.Text
                    Me.Open()
                    g00.Find("bl_no = " + finder)
                End If

            Case MenuType.Delete
                If Me.Delete("mmd300_f10") = ExcuteResult.Succeeded Then
                    PutMessage("SYS_DELETE", "Delete Success.")
                    Dim finder As String = po_no.Text
                    Me.Open()
                    g00.Find("po_no = " + finder)
                End If
            Case Else

                MyBase.MenuButton_Click(mty)

        End Select

    End Sub
    Public Overrides Sub NewForm()
        'bl_no.Text = ""
        'Me.OpenTrigger("mmd300_g00")
    End Sub

    'Public Overrides Function save() As Boolean
    '    Dim key1 As String = g00.Text("req_no")

    '    Dim keys(0) As String
    '    keys(0) = "req_no=" + key1

    '    Call MyBase.Save()

    '    g00.Open()
    '    g00.Find(keys(0))
    'End Function

    Private Sub f_category_TextChanged(sender As Object, e As EventArgs) Handles f_category.TextChanged
        If f_category.Text = "DM000100" Then
            g10.Visible = True
            g20.Visible = False
        Else
            g10.Visible = False
            g20.Visible = True
        End If

        Me.Open()
    End Sub

    Private Sub enable_Bl(blnYn As Boolean)
        bl_dt.Enabled = blnYn
        etd.Enabled = blnYn
        eta.Enabled = blnYn
        bl_serial.Enabled = blnYn
        port_loading.Enabled = blnYn
        bl_rmks.Enabled = blnYn
        bl_dest.Enabled = blnYn

        vs_name.Enabled = blnYn
        vs_origin.Enabled = blnYn
        vs_ton.Enabled = blnYn
        vs_capacity.Enabled = blnYn

        vs_packstyle.Enabled = blnYn
        vs_packcount.Enabled = blnYn
    End Sub


    Private Sub g10_AddedRow(sender As Object, RowIndex As Integer) Handles g10.AddedRow
        If g10.RowCount > 0 Then
            g10.Text("bl_container", RowIndex) = g10.Text("bl_container", RowIndex - 1)
        End If
    End Sub

    Private Sub g20_AddedRow(sender As Object, RowIndex As Integer) Handles g20.AddedRow
        If g20.RowCount > 0 Then
            g20.Text("bl_container", RowIndex) = g20.Text("bl_container", RowIndex - 1)
        End If
    End Sub
    Private Sub Read()
        If status.Text = "MM050710" Then
            Call enable_Bl(True)
        ElseIf status.Text = "MM050720" Then
            'PO(true), PI(true), LC(false)
            Call enable_Bl(True)
        ElseIf status.Text = "MM050730" Then
            'PO(true), PI(true), LC(false)
            Call enable_Bl(False)
        Else
            'PO(false), PI(false), LC(false)
            Call enable_Bl(False)
        End If
    End Sub
    Private Sub g00_AfterMoveRow(sender As Object, PrevRowIndex As Integer, RowIndex As Integer) Handles g00.AfterMoveRow
        Read()
    End Sub

    Private Sub btn_copy_Click(sender As Object, e As EventArgs) Handles btn_copy.Click
        If f_category.Text = "DM000100" Then

            g10.InsertNewRow(g10.RowIndex + 1)
            For i As Integer = 0 To g10.ColumnCount - 1
                If g10.FieldName(i) <> "seq" Then
                    g10.Text(i) = g10.Text(i, g10.RowIndex - 1)
                End If
            Next

        Else

            g20.InsertNewRow(g20.RowIndex + 1)
            For i As Integer = 0 To g20.ColumnCount - 1
                If g20.FieldName(i) <> "seq" Then
                    g20.Text(i) = g20.Text(i, g20.RowIndex - 1)
                End If
            Next

        End If
    End Sub
End Class
